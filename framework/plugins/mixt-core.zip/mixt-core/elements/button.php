<?php

/**
 * Button Element
 */
class Mixt_Button {

	/**
	 * @var array $types
	 * @var array $sizes
	 * @var array $colors
	 * @var array animations
	 * @var array icon_animations
	 */
	public $types, $sizes, $colors, $animations, $icon_animations;
	
	public function __construct() {
		$this->types = mixt_element_assets('button', 'types');
		$this->sizes = mixt_element_assets('button', 'sizes');
		$this->colors = mixt_element_assets('colors', 'buttons');
		$this->animations = mixt_element_assets('button', 'animations');
		$this->icon_animations = mixt_element_assets('button', 'icon-animations');

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_button', array($this, 'shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_button',
			'title'    => esc_html__( 'Button', 'mixt-core' ),
			'template' => '[mixt_button {{attributes}}][/mixt_button]',
			'params'   => array(
				'type' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Type', 'mixt-core' ),
					'options' => $this->types,
					'std' => '',
				),
				'size' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Size', 'mixt-core' ),
					'options' => $this->sizes,
					'std' => '',
				),
				'style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Style', 'mixt-core' ),
					'options' => array(
						'solid'   => esc_html__( 'Solid', 'mixt-core' ),
						'outline' => esc_html__( 'Outlined', 'mixt-core' ),
					),
					'std' => 'solid',
				),
				'color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Color', 'mixt-core' ),
					'options'  => $this->colors,
					'class'    => 'color-select button-colors',
					'std'      => 'default',
				),
				'hover_style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Hover Style', 'mixt-core' ),
					'options' => array(
						'solid'   => esc_html__( 'Solid', 'mixt-core' ),
						'outline' => esc_html__( 'Outlined', 'mixt-core' ),
					),
					'std' => 'solid',
				),
				'hover_color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Hover Color', 'mixt-core' ),
					'options'  => $this->colors,
					'class'    => 'color-select button-colors',
					'std'      => 'default',
				),
				'text' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Text', 'mixt-core' ),
					'std'   => 'Button Text',
				),
				'link' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Link', 'mixt-core' ),
				),
				'animation' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Animation', 'mixt-core' ),
					'options' => $this->animations,
				),
				'icon' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Icon', 'mixt-core' ),
				),
				'icon_align' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Alignment', 'mixt-core' ),
					'options' => array(
						'left'  => esc_html__( 'Left', 'mixt-core' ),
						'right' => esc_html__( 'Right', 'mixt-core' ),
					),
					'std' => 'left',
				),
				'icon_anim' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Animation', 'mixt-core' ),
					'options' => $this->icon_animations,
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Button', 'mixt-core' ),
			'description' => esc_html__( 'You know you want to press it', 'mixt-core' ),
			'base'        => 'mixt_button',
			'icon'        => 'mixt_button',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Type', 'mixt-core' ),
					'param_name' => 'type',
					'value'      => array_flip($this->types),
					'std'        => '',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Size', 'mixt-core' ),
					'param_name' => 'size',
					'value'      => array_flip($this->sizes),
					'std'        => '',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Style', 'mixt-core' ),
					'param_name' => 'style',
					'value'      => array(
						esc_html__( 'Solid', 'mixt-core' )    => 'solid',
						esc_html__( 'Outlined', 'mixt-core' ) => 'outline',
					),
					'std'        => 'solid',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Color', 'mixt-core' ),
					'param_name' => 'color',
					'value'      => array_flip($this->colors),
					'std'        => 'default',
					'param_holder_class' => 'color-select button-colors',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Hover Style', 'mixt-core' ),
					'param_name' => 'hover_style',
					'value'      => array(
						esc_html__( 'Solid', 'mixt-core' )    => 'solid',
						esc_html__( 'Outlined', 'mixt-core' ) => 'outline',
					),
					'std'        => 'solid',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Hover Color', 'mixt-core' ),
					'param_name' => 'hover_color',
					'value'      => array_flip($this->colors),
					'std'        => 'default',
					'param_holder_class' => 'color-select button-colors',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Text', 'mixt-core' ),
					'param_name'  => 'text',
					'admin_label' => true,
					'std'         => 'Button Text',
				),
				array(
					'type'        => 'vc_link',
					'heading'     => esc_html__( 'URL (Link)', 'mixt-core' ),
					'param_name'  => 'link',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Animation', 'mixt-core' ),
					'param_name' => 'animation',
					'value'      => array_flip($this->animations),
					'std'        => '',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),

				// Icon Tab
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Type', 'mixt-core' ),
					'value'       => array(
						esc_html__( 'Image', 'mixt-core' ) => 'image',
						'Font Awesome' => 'fontawesome',
						'Typicons'     => 'typicons',
						'Entypo'       => 'entypo',
						'Linecons'     => 'linecons',
					),
					'param_name'  => 'icon_type',
					'std'         => 'fontawesome',
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_fontawesome',
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_typicons',
					'settings'    => array( 'type' => 'typicons' ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'typicons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_entypo',
					'settings'    => array( 'type' => 'entypo' ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'entypo' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_linecons',
					'settings'    => array( 'type' => 'linecons' ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'linecons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Alignment', 'mixt-core' ),
					'param_name' => 'icon_align',
					'value'      => array(
						esc_html__( 'Left', 'mixt-core' )  => 'left',
						esc_html__( 'Right', 'mixt-core' ) => 'right',
					),
					'std'        => 'left',
					'group'      => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Animation', 'mixt-core' ),
					'param_name' => 'icon_anim',
					'value'      => array_flip($this->icon_animations),
					'group'      => esc_html__( 'Icon', 'mixt-core' ),
				),

				// Design Tab
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-core' ),
					'group'      => esc_html__( 'Design Options', 'mixt-core' ),
					'param_name' => 'css',
				),
			),
		) );
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'type'        => '',
			'size'        => '',
			'style'       => 'solid',
			'color'       => 'default',
			'hover_style' => 'solid',
			'hover_color' => 'default',
			'animation'   => '',
			'class'       => '',

			'text'        => 'Button Text',
			'link'        => '',
			
			'css'         => '',
			
			'icon'        => '',
			'icon_align'  => 'left',
			'icon_anim'   => '',
			'icon_type'   => 'fontawesome',
			'icon_fontawesome' => '',
			'icon_typicons'    => '',
			'icon_entypo'      => '',
			'icon_linecons'    => '',
		), $atts );

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_button', $atts );
		}

		$args['icon'] = mixt_element_icon_class($args);

		extract($args);

		$classes = 'btn mixt-button';
		$style = ( $style == 'solid' ) ? '' : 'outline-';
		$hover_style = ( $hover_style == 'solid' ) ? '' : 'outline-';
		$classes .= " btn-{$style}{$color}";
		if ( $animation == '' ) {
			$classes .= " btn-hover-{$hover_style}{$hover_color}";
		} else {
			$classes .= " btn-hover-$hover_color btn-$animation btn-$animation-$hover_color";
		}
		if ( $type != '' ) $classes .= " btn-$type";
		if ( $size != '' ) $classes .= " $size";
		if ( $class != '' ) $classes .= ' ' . $class;

		$classes = mixt_element_sanitize_html_classes($classes);

		$icon_l = $icon_r = '';
		if ( $icon != '' ) {
			$icon = "<i class='$icon'></i>";
			if ( $icon_anim != '' ) {
				if ( $icon_anim == 'icon-goDown' || $icon_anim == 'hover-icon-goDown' ) {
					$classes .= " btn-$icon_anim";
				} else {
					$classes .= ' icon-cont';
					$icon = "<span class='mixt-icon anim $icon_anim'>$icon</span>";
				}
			}
			if ( $icon_align == 'left' ) {
				$classes .= ' icon-l';
				$icon_l = $icon;
			} else {
				$classes .= ' icon-r';
				$icon_r = $icon;
			}
		}

		$link = ( '||' === $link ) ? '' : $link;
		$link = vc_build_link($link);

		$text = esc_html($text);

		return "<a href='" . esc_attr($link['url']) . "' class='$classes' title='" . esc_attr($link['title']) . "' target='" . esc_attr($link['target']) . "'>{$icon_l}{$text}{$icon_r}</a>";
	}
}
new Mixt_Button;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Button extends WPBakeryShortCode {}
}
