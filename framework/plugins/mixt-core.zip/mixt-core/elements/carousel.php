<?php

/**
 * Carousel Element
 */
class Mixt_Carousel {

	function __construct() {
		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_carousel', array($this, 'shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_carousel',
			'title'    => esc_html__( 'Carousel', 'mixt-core' ),
			'template' => '[mixt_carousel {{attributes}}]{{content}}[/mixt_carousel]',
			'params'   => array(
				'type' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Content Type', 'mixt-core' ),
					'options' => array(
						'html' => esc_html__( 'HTML', 'mixt-core' ),
						'img'  => esc_html__( 'Images', 'mixt-core' ),
					),
				),
				'content' => array(
					'type'     => 'encoded_textarea',
					'label'    => esc_html__( 'Content', 'mixt-core' ),
					'desc'     => esc_html__( 'Content for each slide, separated by 3 underscores (___). Supports shortcodes.', 'mixt-core' ),
					'required' => array('type', '=', 'html'),
				),
				'images' => array(
					'type'     => 'media_multi',
					'label'    => esc_html__( 'Images', 'mixt-core' ),
					'desc'     => esc_html__( 'Select images from library', 'mixt-core' ),
					'required' => array('type', '=', 'img'),
				),
				'img_size' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Image Size', 'mixt-core' ),
					'desc'     => esc_html__( 'Example: thumbnail, medium, large, full or custom image size in pixels (width x height). Default: thumbnail', 'mixt-core' ),
					'required' => array('type', '=', 'img'),
				),
				'style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Item Style', 'mixt-core' ),
					'desc'    => esc_html__( 'Select the item style', 'mixt-core' ),
					'options' => array(
						'plain' => esc_html__( 'Plain', 'mixt-core' ),
						'boxed' => esc_html__( 'Boxed', 'mixt-core' ),
					),
				),
				'orient' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Orientation', 'mixt-core' ),
					'options' => array(
						'horizontal' => esc_html__( 'Horizontal', 'mixt-core' ),
						'vertical'   => esc_html__( 'Vertical', 'mixt-core' ),
					),
				),
				'mode' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Slide Mode', 'mixt-core' ),
					'options' => array(
						'slide' => esc_html__( 'Slide', 'mixt-core' ),
						'fade'  => esc_html__( 'Fade', 'mixt-core' ),
					),
				),
				'settings' => array(
					'type'    => 'checkbox',
					'label'   => esc_html__( 'General Settings', 'mixt-core' ),
					'options' => array(
						'auto' => esc_html__( 'Autoplay', 'mixt-core' ),
						'loop' => esc_html_x( 'Loop', 'slider', 'mixt-core' ),
					),
					'std' => '',
				),
				'speed' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Slide Interval', 'mixt-core' ),
					'desc'  => esc_html__( 'Pause between slides for autoplay (in ms)', 'mixt-core' ),
					'std'   => '5000',
				),
				'items' => array(
					'type'  => 'text',
					'label' => esc_html_x( 'Items', 'slider', 'mixt-core' ),
					'desc'  => esc_html__( 'Number of items visible', 'mixt-core' ),
					'std'   => '1',
				),
				'items_tablet' => array(
					'type'  => 'text',
					'label' => esc_html_x( 'Items on Tablet', 'slider', 'mixt-core' ),
					'std'   => '1',
				),
				'items_mobile' => array(
					'type'  => 'text',
					'label' => esc_html_x( 'Items on Mobile', 'slider', 'mixt-core' ),
					'std'   => '1',
				),
				'ui_settings' => array(
					'type'    => 'checkbox',
					'label'   => esc_html__( 'UI Settings', 'mixt-core' ),
					'options' => array(
						'pag'      => esc_html__( 'Pagination', 'mixt-core' ),
						'nav'      => esc_html__( 'Nav Buttons', 'mixt-core' ),
						'dark-nav' => esc_html__( 'Dark Nav Buttons', 'mixt-core' ),
						'padding'  => esc_html__( 'Navigation Padding', 'mixt-core' ),
						'eqslides' => esc_html__( 'Equal Slide Height', 'mixt-core' ),
					),
					'std' => '',
				),
				'action' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Click Action', 'mixt-core' ),
					'options' => array(
						'none'     => esc_html__( 'None', 'mixt-core' ),
						'lightbox' => esc_html__( 'Lightbox', 'mixt-core' ),
						'custom'   => esc_html__( 'Custom link', 'mixt-core' ),
					),
				),
				'links' => array(
					'type'     => 'exploded_textarea',
					'label'    => esc_html__( 'Custom Links', 'mixt-core' ),
					'desc'     => esc_html__( 'Enter links for each slide, divided with linebreaks (Enter)', 'mixt-core' ),
					'required' => array('action', '=', 'custom'),
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Carousel', 'mixt-core' ),
			'description' => esc_html__( 'Image or HTML carousel', 'mixt-core' ),
			'base'        => 'mixt_carousel',
			'icon'        => 'mixt_carousel',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Content Type', 'mixt-core' ),
					'param_name'  => 'type',
					'admin_label' => true,
					'value'       => array(
						esc_html__( 'HTML', 'mixt-core' ) => 'html',
						esc_html__( 'Images', 'mixt-core' ) => 'img',
					),
				),
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Content', 'mixt-core' ),
					'description' => esc_html__( 'Content for each slide, separated by 3 underscores (___). Supports shortcodes.', 'mixt-core' ),
					'param_name'  => 'content',
					'dependency'  => array( 'element' => 'type', 'value' => 'html' ),
				),
				array(
					'type'        => 'attach_images',
					'heading'     => esc_html__( 'Images', 'mixt-core' ),
					'description' => esc_html__( 'Select images from library', 'mixt-core' ),
					'param_name'  => 'images',
					'dependency'  => array( 'element' => 'type', 'value' => 'img' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Image Size', 'mixt-core' ),
					'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size. If used slides per view, this will be used to define carousel wrapper size.', 'js_composer' ),
					'param_name'  => 'img_size',
					'dependency'  => array( 'element' => 'type', 'value' => 'img' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Item Style', 'mixt-core' ),
					'description' => esc_html__( 'Select the item style', 'mixt-core' ),
					'param_name'  => 'style',
					'value'       => array(
						esc_html__( 'Plain', 'mixt-core' ) => 'plain',
						esc_html__( 'Boxed', 'mixt-core' ) => 'boxed',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Orientation', 'mixt-core' ),
					'param_name'  => 'orient',
					'admin_label' => true,
					'value'       => array(
						esc_html__( 'Horizontal', 'js_composer' ) => 'horizontal',
						esc_html__( 'Vertical', 'js_composer' ) => 'vertical'
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Slide Mode', 'mixt-core' ),
					'param_name'  => 'mode',
					'admin_label' => true,
					'value'       => array(
						esc_html__( 'Slide', 'mixt-core' ) => 'slide',
						esc_html__( 'Fade', 'mixt-core' )  => 'fade',
					),
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'General Settings', 'mixt-core' ),
					'param_name'  => 'settings',
					'value'       => array(
						esc_html__( 'Autoplay', 'mixt-core' ) => 'auto',
						esc_html_x( 'Loop', 'slider', 'mixt-core' ) => 'loop',
					),
					'std' => '',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Slider speed', 'js_composer' ),
					'description' => esc_html__( 'Duration of animation between slides (in ms).', 'js_composer' ),
					'param_name'  => 'speed',
					'value'       => '5000',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Items', 'slider', 'mixt-core' ),
					'description' => esc_html__( 'Number of items visible', 'mixt-core' ),
					'param_name'  => 'items',
					'value'       => '1',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Items on Tablet', 'slider', 'mixt-core' ),
					'param_name'  => 'items_tablet',
					'value'       => '1',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Items on Mobile', 'slider', 'mixt-core' ),
					'param_name'  => 'items_mobile',
					'value'       => '1',
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'UI Settings', 'mixt-core' ),
					'param_name'  => 'ui_settings',
					'value'       => array(
						esc_html__( 'Pagination', 'mixt-core' ) => 'pag',
						esc_html__( 'Nav Buttons', 'mixt-core' ) => 'nav',
						esc_html__( 'Dark Nav Buttons', 'mixt-core' ) => 'dark-nav',
						esc_html__( 'Navigation Padding', 'mixt-core' ) => 'padding',
						esc_html__( 'Equal Slide Height', 'mixt-core' ) => 'eqslides',
					),
					'std' => '',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Click Action', 'mixt-core' ),
					'param_name'  => 'action',
					'value'       => array(
						esc_html__( 'None', 'mixt-core' ) => 'none',
						esc_html__( 'Custom link', 'mixt-core' ) => 'custom',
						esc_html__( 'Lightbox', 'mixt-core' ) => 'lightbox',
					),
				),
				array(
					'type'        => 'exploded_textarea',
					'heading'     => esc_html__( 'Custom links', 'js_composer' ),
					'description' => esc_html__( 'Enter links for each slide (Note: divide links with linebreaks (Enter)).', 'js_composer' ),
					'param_name'  => 'links',
					'dependency'  => array( 'element' => 'action', 'value' => 'custom' ),
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name' => 'class',
				),
			),
		) );
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'type'         => 'html',
			'images'       => '',
			'img_size'     => 'thumbnail',
			'items'        => '1',
			'items_tablet' => '1',
			'items_mobile' => '1',
			'mode'         => 'slide',
			'style'        => 'plain',
			'orient'       => 'horizontal',
			'settings'     => '',
			'ui_settings'  => '',
			'speed'        => '5000',
			'action'       => 'none',
			'links'        => '',
			'class'        => '',
		), $atts ) );

		$images = explode(',', $images);
		$settings = explode(',', $settings);
		$ui_settings = explode(',', $ui_settings);

		$classes = 'mixt-carousel mixt-element';
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);

		$slider_classes = 'carousel-slider';
		if ( $type == 'html' ) {
			$slider_classes .= ' html-slider';
			if ( $action == 'lightbox' ) $action = 'none';
		} else {
			$slider_classes .= ' image-slider';
		}
		if ( $orient == 'vertical' ) $slider_classes .= ' vertical';
		if ( $style == 'boxed' ) $slider_classes .= ' boxed theme-bd';
		if ( in_array('dark-nav', $ui_settings) ) $slider_classes .= ' controls-alt';
		if ( in_array('padding', $ui_settings) ) $slider_classes .= ' item-padding';

		$links = explode(',', $links);

		// Enqueue the lightslider plugin
		mixt_element_enqueue_plugin('lightslider');

		if ( $action == 'lightbox' ) {
			// Enqueue the lightGallery plugin
			mixt_element_enqueue_plugin('lightgallery');
		}

		ob_start();
		?>

		<div class="<?php echo $classes; ?>">
			<ul class="<?php echo $slider_classes; ?>" 
				data-mode="<?php echo esc_attr($mode); ?>" 
				data-auto="<?php echo in_array('auto', $settings) ? 'true' : 'false'; ?>" 
				data-loop="<?php echo in_array('loop', $settings) ? 'true' : 'false'; ?>" 
				data-interval="<?php echo esc_attr($speed); ?>" 
				data-items="<?php echo esc_attr($items); ?>" 
				data-items-tablet="<?php echo esc_attr($items_tablet); ?>" 
				data-items-mobile="<?php echo esc_attr($items_mobile); ?>" 
				data-direction="<?php echo esc_attr($orient); ?>" 
				data-lightbox="<?php echo ( $action == 'lightbox' ) ? 'true' : 'false'; ?>" 
				data-eq-slides="<?php echo in_array('eqslides', $ui_settings) ? 'true' : 'false'; ?>" 
				data-pagination="<?php echo in_array('pag', $ui_settings) ? 'true' : 'false'; ?>" 
				data-navigation="<?php echo in_array('nav', $ui_settings) ? 'true' : 'false'; ?>">

				<?php

				$i = 0;
				$slide_link = '';

				// HTML SLIDES
				if ( $type == 'html' ) {
					$slides = explode('___', html_entity_decode($content));
					foreach ( $slides as $slide_html ) {
						?>
						<li class="slider-item">
							<?php

							if ( $action == 'custom' && ! empty($links[$i]) ) {
								$slide_link = esc_url($links[$i]);
								echo "<a href='$slide_link' class='slide-link'></a>";
							}

							echo do_shortcode($slide_html);

							$i++;

							?>
						</li>
						<?php
					}

				// IMAGE SLIDES
				} else {
					$slide_atts = '';

					foreach ( $images as $attach_id ) {
						if ( $attach_id > 0 ) {
							if ( function_exists('wpb_getImageBySize') ) {
								$post_thumbnail = wpb_getImageBySize( array('attach_id' => $attach_id, 'thumb_size' => $img_size) );
								$thumbnail = $post_thumbnail['thumbnail'];
							} else {
								$thumbnail = wp_get_attachment_image($attach_id, $img_size);
							}
						} else {
							$post_thumbnail = array();

							$post_thumbnail['thumbnail'] = '<img src="' . MIXT_CORE_IMG_PLACEHOLDER . '" />';
							$post_thumbnail['p_img_large'][0] = MIXT_CORE_IMG_PLACEHOLDER;
							$thumbnail = $post_thumbnail['thumbnail'];
						}

						if ( $action == 'custom' && ! empty($links[$i]) ) {
							$slide_link = esc_url($links[$i]);
						} else if ( $action == 'lightbox' ) {
							$image_src = wp_get_attachment_image_src($attach_id, 'full');
							if ( ! empty($image_src[0]) ) {
								$slide_atts =  ' data-src="' . esc_url($image_src[0]) . '"';
							}
						} else {
							$slide_link = false;
						}

						$i++;
						
						echo "<li class='slider-item'$slide_atts>";
							if ( $slide_link ) {
								echo "<a href='$slide_link'>$thumbnail</a>";
							} else {
								echo $thumbnail;
							}
						echo '</li>';
					}
				}

				?>
			</ul>
		</div>
		
		<?php
		return ob_get_clean();
	}
}
new Mixt_Carousel;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Carousel extends WPBakeryShortCode {}
}
