<?php

/**
 * Flipcard Element
 */
class Mixt_Flipcard {

	/** @var array */
	public $colors;
	
	public function __construct() {
		$this->colors = array_merge(
			mixt_element_assets('colors', 'basic'),
			array('transparent' => esc_html__( 'Transparent', 'mixt-core' ))
		);

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_flipcard', array($this, 'shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_flipcard',
			'title'    => esc_html__( 'Flip Card', 'mixt-core' ),
			'template' => '[mixt_flipcard {{attributes}}]{{content}}[/mixt_flipcard]',
			'params'   => array(
				'content' => array(
					'type'   => 'textarea',
					'label'  => esc_html__( 'Content', 'mixt-core' ),
					'desc'   => esc_html__( 'The card\'s content. Separate the front and back side content with 3 underscores (___)', 'mixt-core' ),
					'std'    => "Front Side\n___\nBack Side",
				),
				'dir' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Direction', 'mixt-core' ),
					'desc'    => esc_html__( 'Direction of the card flip', 'mixt-core' ),
					'options' => array(
						'vertical'   => esc_html__( 'Vertical', 'mixt-core' ),
						'horizontal' => esc_html__( 'Horizontal', 'mixt-core' ),
					),
				),
				'front_color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Front Color', 'mixt-core' ),
					'desc'    => esc_html__( 'Front side color', 'mixt-core' ),
					'options' => $this->colors,
					'class'   => 'color-select basic-colors',
					'std'     => 'white',
				),
				'back_color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Back Color', 'mixt-core' ),
					'desc'    => esc_html__( 'Back side color', 'mixt-core' ),
					'options' => $this->colors,
					'class'   => 'color-select basic-colors',
					'std'     => 'black',
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Flip Card', 'mixt-core' ),
			'description' => esc_html__( 'Two sided card that flips', 'mixt-core' ),
			'base'        => 'mixt_flipcard',
			'icon'        => 'mixt_flipcard',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Content', 'mixt-core' ),
					'description' => esc_html__( 'The card\'s content. Separate the front and back side content with 3 underscores (___)', 'mixt-core' ),
					'param_name'  => 'content',
					'admin_label' => true,
					'value'       => "Front Side\n___\nBack Side",
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Direction', 'mixt-core' ),
					'description' => esc_html__( 'Direction of the card flip', 'mixt-core' ),
					'param_name'  => 'dir',
					'admin_label' => true,
					'value'       => array(
						esc_html__( 'Vertical', 'mixt-core' )   => 'vertical',
						esc_html__( 'Horizontal', 'mixt-core' ) => 'horizontal',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Front Color', 'mixt-core' ),
					'description' => esc_html__( 'Front side color', 'mixt-core' ),
					'param_name'  => 'front_color',
					'value'       => array_flip($this->colors),
					'std'         => 'white',
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Back Color', 'mixt-core' ),
					'description' => esc_html__( 'Back side color', 'mixt-core' ),
					'param_name'  => 'back_color',
					'value'       => array_flip($this->colors),
					'std'         => 'black',
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'front-bg' => array(
							'selector' => '.front',
							'label'    => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern'  => 'background-color: {{val}}',
							'group'    => esc_html__( 'Front Side', 'mixt-core' ),
						),
						'front-color' => array(
							'selector' => '.front',
							'label'    => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
							'group'    => esc_html__( 'Front Side', 'mixt-core' ),
						),
						'front-border' => array(
							'selector' => '.front',
							'label'    => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
							'group'    => esc_html__( 'Front Side', 'mixt-core' ),
						),
						'back-bg' => array(
							'selector' => '.back',
							'label'    => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern'  => 'background-color: {{val}}',
							'group'    => esc_html__( 'Back Side', 'mixt-core' ),
						),
						'back-color' => array(
							'selector' => '.back',
							'label'    => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
							'group'    => esc_html__( 'Back Side', 'mixt-core' ),
						),
						'back-border' => array(
							'selector' => '.back',
							'label'    => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
							'group'    => esc_html__( 'Back Side', 'mixt-core' ),
						),
					),
					'group'      => 'Styler',
				),

				// Design Tab
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-core' ),
					'group'      => esc_html__( 'Design Options', 'mixt-core' ),
					'param_name' => 'css',
				),
			),
		) );
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'dir'         => 'vertical',
			'front_color' => 'white',
			'back_color'  => 'black',
			'styler'      => '',
			'css'         => '',
			'class'       => '',
		), $atts );

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_flipcard', $atts );
		}

		// Styler custom design
		if ( $args['styler'] != '' ) {
			$args['class'] .= mixt_element_styler($args['styler']);
		}

		extract($args);

		$classes = 'flip-card mixt-flipcard mixt-element';
		if ( $dir == 'horizontal' ) $classes .= ' flipY';
		if ( $class != '' ) $classes .= ' ' . mixt_core_sanitize_html_classes($class);

		$content_front = $content_back = '';
		$content = explode('___', $content);
		if ( ! empty($content[0]) ) $content_front = do_shortcode( apply_filters('mixt_unautop', $content[0]) );
		if ( ! empty($content[1]) ) $content_back = do_shortcode( apply_filters('mixt_unautop', $content[1]) );
		$classes_front = 'front ' . sanitize_html_class($front_color);
		$classes_back  = 'back ' . sanitize_html_class($back_color);

		return "<div class='$classes'><div class='inner'>" .
				   "<div class='$classes_front'>$content_front</div>" .
				   "<div class='$classes_back'>$content_back</div>" .
			   "</div></div>";
	}
}
new Mixt_Flipcard;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Flipcard extends WPBakeryShortCode {}
}
