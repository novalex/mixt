<?php

/**
 * Form Element
 */
class Mixt_Form {

	/**
	 * @var array $field_types
	 * @var array $columns
	 */
	public $field_types, $columns;
	
	function __construct() {
		$this->field_types = array(
			'text'     => esc_html__( 'Text', 'mixt-core' ),
			'password' => esc_html__( 'Password', 'mixt-core' ),
			'textarea' => esc_html__( 'Textarea', 'mixt-core' ),
			'checkbox' => esc_html__( 'Checkbox', 'mixt-core' ),
		);
		$this->columns = array(
			'col-sm-2'  => esc_html__( '2 Columns', 'mixt-core' ),
			'col-sm-4'  => esc_html__( '4 Columns', 'mixt-core' ),
			'col-sm-6'  => esc_html__( '6 Columns', 'mixt-core' ),
			'col-sm-8'  => esc_html__( '8 Columns', 'mixt-core' ),
			'col-sm-10' => esc_html__( '10 Columns', 'mixt-core' ),
			'col-sm-12' => esc_html__( '12 Columns', 'mixt-core' ),
		);
		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_form', array($this, 'form_shortcode'));
		add_shortcode('mixt_field', array($this, 'field_shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_form',
			'title'    => esc_html__( 'Form', 'mixt-core' ),
			'template' => '[mixt_form {{attributes}}]{{nested}}[/mixt_form]',
			'params'   => array(
				'form_type' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Form Type', 'mixt-core' ),
					'std'     => 'contact',
					'options' => array(
						'contact' => esc_html__( 'Contact', 'mixt-core' ),
						'custom'  => esc_html__( 'Custom', 'mixt-core' ),
					),
				),
				'address' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Email Address', 'mixt-core' ),
					'desc'     => esc_html__( 'Address to send the message to', 'mixt-core' ),
					'std'      => get_option('admin_email'),
					'required' => array('form_type', '=', 'contact'),
				),
				'action' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Form Action', 'mixt-core' ),
					'desc'     => esc_html__( 'Set a custom action for the form', 'mixt-core' ),
					'required' => array('form_type', '=', 'custom'),
				),
				'labels' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Label Display', 'mixt-core' ),
					'std'     => 'top',
					'options' => array(
						'top'  => esc_html__( 'Top', 'mixt-core' ),
						'left' => esc_html__( 'Left', 'mixt-core' ),
						'none' => esc_html__( 'Hidden', 'mixt-core' ),
					),
				),
				'btn_text' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Button Text', 'mixt-core' ),
					'desc'  => esc_html__( 'Text on the submit button', 'mixt-core' ),
					'std'   => esc_html__( 'Submit', 'mixt-core' ),
				),
				'button' => array(
					'type'  => 'button',
					'label' => esc_html__( 'Button Style', 'mixt-core' ),
					'std'   => 'color:primary',
				),
				'btn_cols' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Button Columns', 'mixt-core' ),
					'options' => $this->columns,
					'std'     => 'col-sm-4',
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
			'nested' => array(
				'template' => '[mixt_field {{attributes}}]',
				'params' => array(
					'id' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Field ID', 'mixt-core' ),
					),
					'type' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Field Type', 'mixt-core' ),
						'options' => $this->field_types,
						'std'     => 'text',
					),
					'label' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Field Label', 'mixt-core' ),
					),
					'placeholder' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Placeholder', 'mixt-core' ),
					),
					'required' => array(
						'type' => 'checkbox',
						'label' => esc_html__( 'Required', 'mixt-core' ),
					),
					'cols' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Columns', 'mixt-core' ),
						'options' => $this->columns,
						'std'     => 'col-sm-12',
					),
				),
				'presets' => array(
					array(
						'id'          => 'name',
						'type'        => 'text',
						'label'       => esc_html__( 'Name', 'mixt-core' ),
						'placeholder' => esc_html__( 'Name', 'mixt-core' ),
						'required'    => true,
						'cols'        => 'col-sm-4',
					),
					array(
						'id'          => 'email',
						'type'        => 'text',
						'label'       => esc_html__( 'Email Address', 'mixt-core' ),
						'placeholder' => esc_html__( 'Email Address', 'mixt-core' ),
						'required'    => true,
						'cols'        => 'col-sm-4',
					),
					array(
						'id'          => 'subject',
						'type'        => 'text',
						'label'       => esc_html__( 'Subject', 'mixt-core' ),
						'placeholder' => esc_html__( 'Subject', 'mixt-core' ),
						'required'    => true,
						'cols'        => 'col-sm-4',
					),
					array(
						'id'          => 'message',
						'type'        => 'textarea',
						'label'       => esc_html__( 'Message', 'mixt-core' ),
						'placeholder' => esc_html__( 'Message', 'mixt-core' ),
						'required'    => true,
						'cols'        => 'col-sm-12',
					),
				),
				'child_title'  => esc_html__( 'Form Field', 'mixt-core' ),
				'clone_button' => esc_html__( 'Add Field', 'mixt-core' ),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		// Form
		vc_map( array(
			'name'        => esc_html__( 'Form', 'mixt-core' ),
			'description' => esc_html__( 'A form with custom fields', 'mixt-core' ),
			'base'        => 'mixt_form',
			'icon'        => 'mixt_form',
			'category'    => 'MIXT',
			'as_parent'   => array('only' => 'mixt_field'),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Form Type', 'mixt-core' ),
					'param_name'  => 'form_type',
					'value'       => array(
						esc_html__( 'Contact', 'mixt-core' ) => 'contact',
						esc_html__( 'Custom', 'mixt-core' )  => 'custom',
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Email Address', 'mixt-core' ),
					'description' => esc_html__( 'Address to send the message to', 'mixt-core' ),
					'param_name'  => 'address',
					'value'       => get_option('admin_email'),
					'dependency'  => array( 'element' => 'form_type', 'value' => 'contact' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Form Action', 'mixt-core' ),
					'description' => esc_html__( 'Set a custom action for the form', 'mixt-core' ),
					'param_name'  => 'action',
					'dependency'  => array( 'element' => 'form_type', 'value' => 'custom' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Label Position', 'mixt-core' ),
					'param_name'  => 'labels',
					'value'       => array(
						esc_html__( 'Top', 'mixt-core' )  => 'top',
						esc_html__( 'Left', 'mixt-core' ) => 'left',
						esc_html__( 'Hidden', 'mixt-core' ) => 'none',
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Button Text', 'mixt-core' ),
					'description' => esc_html__( 'Text on the submit button', 'mixt-core' ),
					'param_name'  => 'btn_text',
				),
				array(
					'type'       => 'button',
					'heading'    => esc_html__( 'Button Style', 'mixt-core' ),
					'param_name' => 'button',
					'std'        => 'color:primary',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Button Columns', 'mixt-core' ),
					'param_name' => 'btn_cols',
					'value'      => array_flip($this->columns),
					'std'        => 'col-sm-4',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),
			),
		) );

		// Field
		vc_map( array(
			'name'        => esc_html__( 'Form Field', 'mixt-core' ),
			'base'        => 'mixt_field',
			'icon'        => 'mixt_form',
			'category'    => 'MIXT',
			'as_child'    => array('only' => 'mixt_form'),
			'params'      => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Field ID', 'mixt-core' ),
					'param_name'  => 'id',
					'admin_label' => true,
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Field Type', 'mixt-core' ),
					'param_name' => 'type',
					'value'      => array_flip($this->field_types),
					'std'        => 'text',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Field Label', 'mixt-core' ),
					'param_name' => 'label',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Placeholder', 'mixt-core' ),
					'param_name' => 'placeholder',
				),
				array(
					'type'       => 'checkbox',
					'heading'    => esc_html__( 'Required', 'mixt-core' ),
					'param_name' => 'required',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Columns', 'mixt-core' ),
					'param_name' => 'cols',
					'value'      => array_flip($this->columns),
					'std'        => 'col-sm-12',
				),
			),
		) );
	}

	/**
	 * Render form shortcode
	 */
	public function form_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'form_type' => 'contact',
			'address'   => '',
			'action'    => $_SERVER['REQUEST_URI'],
			'labels'    => 'top',
			'btn_text'  => esc_html__( 'Submit', 'mixt-core' ),
			'button'    => 'color:primary',
			'btn_cols'  => 'col-sm-4',
			'class'     => '',
		), $atts ) );

		$classes = 'mixt-form mixt-element form-cols row';
		if ( $labels == 'none' ) { $classes .= ' form-no-labels'; }
		else if ( $labels != 'top' ) $classes .= ' form-labels-' . $labels;
		if ( $class != '' ) $classes .= ' ' . $class;

		$classes = mixt_core_sanitize_html_classes($classes);

		$submit_button = '<button type="submit" name="mixt-form-submit" class="' . mixt_element_button($button) . '">' . esc_html($btn_text) . '</button>';
		$form_message = '';

		// Send the email if the form type is contact
		if ( $form_type == 'contact' && $address != '' && isset($_POST['mixt-form-submit']) ) {
			$name    = sanitize_text_field($_POST['mixt-field-name']);
			$from    = sanitize_email($_POST['mixt-field-email']);
			$subject = sanitize_text_field($_POST['mixt-field-subject']);
			$message = esc_textarea($_POST['mixt-field-message']);
		
			$headers = "From: $name <$from>\r\n";
		
			if ( wp_mail( $address, $subject, $message, $headers ) ) {
				$submit_button = '';
				$form_message = '<div class="alert alert-success" role="alert">' .
									__( '<strong>Message sent successfully!</strong> We will contact you shortly.', 'mixt-core' ) .
								'</div>';
			} else {
				$form_message = '<div class="alert alert-danger" role="alert">' .
									__( '<strong>An error occurred!</strong> Please try again later.', 'mixt-core' ) .
								'</div>';
			}
		}

		$action = esc_attr($action);

		$html = "<form action='$action' method='post' class='$classes'>";
			$html .= do_shortcode($content);
			$html .= '<div class="submit-box form-group ' . sanitize_html_class($btn_cols) . '">' . $submit_button . '</div>';
			if ( $form_message != '' ) $html .= '<div class="alert-box col-sm-12">' . $form_message . '</div>';
		$html .= '</form>';

		return $html;
	}

	/**
	 * Render field shortcode
	 */
	public function field_shortcode( $atts ) {
		extract( shortcode_atts( array(
			'id'          => '',
			'type'        => 'text',
			'label'       => '',
			'placeholder' => '',
			'std'         => '',
			'required'    => false,
			'cols'        => 'col-sm-12',
		), $atts ) );

		$input_atts = '';
		if ( $id != '' ) {
			$id = 'mixt-field-' . esc_attr($id);
			if ( isset($_POST[$id]) ) $std = $_POST[$id];
			$input_atts = "id='$id' name='$id'";
		}

		$classes = 'mixt-field form-group ' . sanitize_html_class($cols);
		$input_classes = 'form-control';

		if ( $required ) $input_atts .= ' required';
		if ( $placeholder != '' ) {
			if ( $required ) $placeholder .= ' *';
			$input_atts .= ' placeholder="' . esc_attr($placeholder) . '"';
		}

		$label_html = '';
		if ( $label != '' ) {
			if ( $required ) $label .= ' <small class="req">*</small>';
			$label_html = "<label for='$id'>" . $label . "</label>";
		}

		switch ( $type ) {
			case 'text':
			case 'password':
				$input = "$label_html <input type='" . esc_attr($type) . "' $input_atts class='$input_classes' value='" . esc_attr($std) . "' />";
				break;
			case 'textarea':
				$input = "$label_html <textarea $input_atts rows='4' class='$input_classes'>" . esc_textarea($std) . '</textarea>';
				break;
			case 'checkbox':
				$input_classes = trim(str_replace('form-control', '', $input_classes));
				$input = "<input type='checkbox' $input_atts class='$input_classes' value='true' " . ( $std == true ? 'checked' : '' ) . "> $label_html";
				break;
			default:
				$input = '<p>Invalid input type!</p>';
				break;
		}

		return "<fieldset class='$classes'>$input</fieldset>";
	}
}
new Mixt_Form;

if ( class_exists('WPBakeryShortCodesContainer') ) {
	class WPBakeryShortCode_Mixt_Form extends WPBakeryShortCodesContainer {}
}

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Field extends WPBakeryShortCode {}
}
