<?php

/**
 * Headline Element
 */
class Mixt_Headline {

	/**
	 * @var array $colors
	 * @var array $styles
	 */
	public $colors, $styles;
	
	public function __construct() {
		$this->colors = array_merge(
			mixt_element_assets('colors', 'elements'),
			array( 'accent' => esc_html__( 'Theme Accent', 'mixt' ) )
		);
		$this->styles = array(
			'sideline'  => esc_html__( 'Lines on the side', 'mixt-core' ),
			'line'      => esc_html__( 'Line separator', 'mixt-core' ),
			'icon'      => esc_html__( 'Icon separator', 'mixt-core' ),
			'icon-line' => esc_html__( 'Icon separator with lines', 'mixt-core' ),
		);
		
		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_headline', array($this, 'shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_headline',
			'title'    => esc_html__( 'Headline', 'mixt-core' ),
			'template' => '[mixt_headline {{attributes}}]{{content}}[/mixt_headline]',
			'params'   => array(
				'style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Style', 'mixt-core' ),
					'options' => $this->styles,
					'std'     => 'sideline',
				),
				'content' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Text', 'mixt-core' ),
					'desc'  => esc_html__( 'Heading text', 'mixt-core' ),
					'std'   => 'Text',
				),
				'align' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Align', 'mixt-core' ),
					'desc'    => esc_html__( 'Heading alignment', 'mixt-core' ),
					'options' => array(
						'left'   => esc_html__( 'Left', 'mixt-core' ),
						'center' => esc_html__( 'Center', 'mixt-core' ),
						'right'  => esc_html__( 'Right', 'mixt-core' ),
					),
					'std'     => 'left',
				),
				'tag' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Tag', 'mixt-core' ),
					'desc'    => esc_html__( 'Heading tag', 'mixt-core' ),
					'options' => array(
						'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
					),
					'std' => 'h3',
				),
				'line_style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Line Style', 'mixt-core' ),
					'options' => array(
						'solid'  => esc_html__( 'Solid', 'mixt-core' ),
						'dashed' => esc_html__( 'Dashed', 'mixt-core' ),
						'dotted' => esc_html__( 'Dotted', 'mixt-core' ),
						'double' => esc_html__( 'Double', 'mixt-core' ),
					),
					'std'     => 'solid',
				),
				'sep_position' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Separator Position', 'mixt-core' ),
					'options'  => array(
						'top'    => esc_html__( 'Top', 'mixt-core' ),
						'middle' => esc_html__( 'Middle', 'mixt-core' ),
						'bottom' => esc_html__( 'Bottom', 'mixt-core' ),
					),
					'std'      => 'middle',
					'required' => array('style', '=', 'line|icon|icon-line'),
				),
				'color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Color', 'mixt-core' ),
					'options' => $this->colors,
					'class'   => 'color-select all-colors',
				),
				'icon_type' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Icon Type', 'mixt-core' ),
					'options'  => array(
						''      => esc_html__( 'Select an icon type', 'mixt-core' ),
						'icon'  => esc_html__( 'Font Icon', 'mixt-core' ),
						'image' => esc_html__( 'Image', 'mixt-core' ),
					),
					'std'      => '',
					'required' => array('style', '=', 'icon|icon-line'),
				),
				'icon' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Icon', 'mixt-core' ),
					'std'      => 'fa fa-check',
					'required' => array('icon_type', '=', 'icon'),
				),
				'image' => array(
					'type'     => 'media',
					'label'    => esc_html__( 'Icon', 'mixt-core' ),
					'required' => array('icon_type', '=', 'image'),
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Headline', 'mixt-core' ),
			'description' => esc_html__( 'Heading with separator', 'mixt-core' ),
			'base'        => 'mixt_headline',
			'icon'        => 'mixt_headline',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Style', 'mixt-core' ),
					'param_name'  => 'style',
					'std'         => 'sideline',
					'value'       => array_flip($this->styles),
				),
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Content', 'mixt-core' ),
					'description' => esc_html__( 'Heading text and, optionally, subheading, separated by 3 underscores (___)', 'mixt-core' ),
					'param_name'  => 'content',
					'admin_label' => true,
					'std'         => 'Text',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Align', 'mixt-core' ),
					'description' => esc_html__( 'Heading alignment', 'mixt-core' ),
					'param_name'  => 'align',
					'value'       => array(
						esc_html__( 'Left', 'mixt-core' )   => 'left',
						esc_html__( 'Center', 'mixt-core' ) => 'center',
						esc_html__( 'Right', 'mixt-core' )  => 'right',
					),
					'std'         => 'left',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Tag', 'mixt-core' ),
					'description' => esc_html__( 'Heading tag', 'mixt-core' ),
					'param_name'  => 'tag',
					'value'       => array(
						'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
					),
					'std'         => 'h3',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Line Style', 'mixt-core' ),
					'param_name'  => 'line_style',
					'value'       => array(
						esc_html__( 'Solid', 'mixt-core' )  => 'solid',
						esc_html__( 'Dashed', 'mixt-core' ) => 'dashed',
						esc_html__( 'Dotted', 'mixt-core' ) => 'dotted',
						esc_html__( 'Double', 'mixt-core' ) => 'double',
					),
					'std'         => 'solid',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array('sideline', 'line', 'icon-line'),
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Separator Position', 'mixt-core' ),
					'param_name'  => 'sep_position',
					'value'       => array(
						esc_html__( 'Top', 'mixt-core' )    => 'top',
						esc_html__( 'Middle', 'mixt-core' ) => 'middle',
						esc_html__( 'Bottom', 'mixt-core' ) => 'bottom',
					),
					'std'         => 'middle',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array('line', 'icon', 'icon-line'),
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Color', 'mixt-core' ),
					'param_name' => 'color',
					'value'      => array_flip($this->colors),
					'param_holder_class' => 'vc_colored-dropdown',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),

				// Icon Tab
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Type', 'mixt-core' ),
					'value'       => array(
						esc_html__( 'Image', 'mixt-core' ) => 'image',
						'Font Awesome' => 'fontawesome',
						'Typicons'     => 'typicons',
						'Entypo'       => 'entypo',
						'Linecons'     => 'linecons',
					),
					'param_name'  => 'icon_type',
					'std'         => 'fontawesome',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array('icon', 'icon-line'),
					),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_fontawesome',
					'settings'    => array( 'emptyIcon' => false ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_typicons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'typicons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'typicons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_entypo',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'entypo',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'entypo' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_linecons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'linecons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'linecons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'attach_image',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'image',
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'image' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'color' => array(
							'selector' => '.headline-content',
							'label'    => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
						),
						'line-color' => array(
							'selector' => '.sideline:after',
							'label'    => esc_html__( 'Line Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
							'cols'     => '3',
							'group'    => esc_html__( 'Separator', 'mixt-core' ),
						),
						'thickness' => array(
							'type'     => 'unit',
							'selector' => '.sideline:after',
							'label'    => esc_html__( 'Thickness', 'mixt-core' ),
							'pattern'  => 'border-top-width: {{val}}',
							'cols'     => '3',
							'group'    => esc_html__( 'Separator', 'mixt-core' ),
						),
						'icon-color' => array(
							'selector' => '.sep-icon',
							'label'    => esc_html__( 'Icon Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
							'cols'     => '3',
							'group'    => esc_html__( 'Separator', 'mixt-core' ),
						),
						'sep-width' => array(
							'type'     => 'unit',
							'selector' => '.separator',
							'label'    => esc_html__( 'Separator Width', 'mixt-core' ),
							'pattern'  => 'width: {{val}}',
							'cols'     => '3',
							'group'    => esc_html__( 'Separator', 'mixt-core' ),
						),
					),
					'group'      => 'Styler',
				),
			),
		));
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'style'            => 'sideline',
			'text'             => '',
			'desc'             => '',
			'align'            => 'left',
			'tag'              => 'h3',
			'line_style'       => '',
			'color'            => '',
			'sep_position'     => 'middle',
			'class'            => '',
			
			'icon'             => '',
			'image'            => '',
			'icon_type'        => 'fontawesome',
			'icon_fontawesome' => '',
			'icon_typicons'    => '',
			'icon_entypo'      => '',
			'icon_linecons'    => '',

			'styler'           => '',
		), $atts );

		extract($args);

		// Styler custom design
		if ( $styler != '' ) {
			$class .= mixt_element_styler($styler);
		}

		$classes = "title headline mixt-headline mixt-element align-$align style-$style";
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);

		$content = explode('___', $content);

		if ( $text == '' ) $text = trim($content[0]);

		if ( $desc == '' && array_key_exists(1, $content) ) $desc = trim($content[1]);
		if ( $desc != '' ) $classes .= ' has-desc';

		$line_class = '';

		if ( $color == '' ) { $line_class .= 'theme-bd'; }
		else if ( $color == 'accent' ) { $line_class .= 'theme-accent-bd'; }
		else { $line_class .= ' ' . $color; }

		if ( $line_style != '' ) $line_class .= ' ' . $line_style;
		
		$line = '<span class="sideline ' . mixt_element_sanitize_html_classes($line_class) . '"></span>';

		$left_content = $right_content = $separator = '';

		if ( $style == 'sideline' ) {
			$left_content = '<div class="headline-left">' . $line . '</div>';
			$right_content = '<div class="headline-right">' . $line . '</div>';
		} else {
			$left_content = '<div class="headline-left"></div>';
			$right_content = '<div class="headline-right"></div>';
			
			if ( $style == 'line' ) {
				$separator = $line;
			} else {
				$icon = '<span class="sep-icon">';
				if ( $icon_type == 'image' ) {
					$icon .= wp_get_attachment_image($image, 'full');
				} else {
					$icon .= '<i class="' . mixt_element_icon_class($args) . '"></i>';
				}
				$icon .= '</span>';

				if ( $style == 'icon' || $style == 'icon-line' ) {
					$separator = $icon;

					if ( $style == 'icon-line' ) {
						if ( $align == 'center' || $align == 'right' ) { $separator = $line . $separator; }
						if ( $align == 'center' || $align == 'left' ) { $separator .= $line; }
					}
				}
			}
			$separator = '<div class="separator">' . $separator . '</div>';
		}

		ob_start();

		?>

		<div class="<?php echo $classes; ?>">
			<?php if ( $align == 'center' || $align == 'right' ) { echo $left_content; } ?>
			<div class="headline-content">
				<?php if ( $sep_position == 'top' ) { echo $separator; } ?>
				<?php echo "<$tag class='heading'>" . apply_filters('mixt_unautop', $text) . "</$tag>"; ?>
				<?php if ( $sep_position == 'middle' ) { echo $separator; } ?>
				<?php if ( $desc != '' ) echo '<p class="subheading color-fade">' . apply_filters('mixt_unautop', $desc) . '</p>'; ?>
				<?php if ( $sep_position == 'bottom' ) { echo $separator; } ?>
			</div>
			<?php if ( $align == 'center' || $align == 'left' ) { echo $right_content; } ?>
		</div>

		<?php

		return ob_get_clean();
	}
}
new Mixt_Headline;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Headline extends WPBakeryShortCode {}
}
