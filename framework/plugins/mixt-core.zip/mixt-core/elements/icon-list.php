<?php

/**
 * Icon List Element
 */
class Mixt_Iconlist extends Mixt_Element {

	/**
	 * @var array $colors
	 * @var array $icon_sizes
	 * @var array $icon_styles
	 * @var array $icon_colors
	 * @var array $image_styles
	 */
	public $colors, $icon_sizes, $icon_styles, $icon_colors, $image_styles;
	
	public function __construct() {
		parent::__construct();

		$this->colors = mixt_element_assets('colors', 'basic');
		$this->icon_styles = mixt_element_assets('icon-styles');
		$this->icon_sizes = mixt_element_assets('icon-sizes');
		$this->icon_colors = array_merge(
			array( 'auto' => esc_html__( 'Auto', 'mixt-core' ) ),
			$this->colors
		);
		$this->image_styles = mixt_element_assets('image-styles');

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_iconlist', array($this, 'list_shortcode'));
		add_shortcode('mixt_iconlist_item', array($this, 'item_shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_iconlist',
			'title'    => esc_html__( 'Icon List', 'mixt-core' ),
			'template' => '[mixt_iconlist {{attributes}}]{{nested}}[/mixt_iconlist]',
			'params'   => array(
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
			'nested'  => array(
				'template' => '[mixt_iconlist_item {{attributes}}]{{content}}[/mixt_iconlist_item]',
				'params' => array(
					'content' => array(
						'type'   => 'encoded_textarea',
						'label'  => esc_html__( 'Content', 'mixt-core' ),
					),
					'align' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Icon Position', 'mixt-core' ),
						'options' => array(
							'left'  => esc_html__( 'Left', 'mixt-core' ),
							'right' => esc_html__( 'Right', 'mixt-core' ),
						),
						'std'     => 'left',
					),
					'animation' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Animation', 'mixt-core' ),
						'options' => $this->animations,
					),
					'icon_type' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Icon Type', 'mixt-core' ),
						'options' => array(
							'icon'  => esc_html__( 'Font Icon', 'mixt-core' ),
							'image' => esc_html__( 'Image', 'mixt-core' ),
						),
						'std'     => 'icon',
					),
					'icon' => array(
						'type'     => 'text',
						'label'    => esc_html__( 'Icon', 'mixt-core' ),
						'std'      => 'fa fa-check',
						'required' => array('icon_type', '=', 'icon'),
					),
					'icon_style' => array(
						'type'     => 'select',
						'label'    => esc_html__( 'Icon Style', 'mixt-core' ),
						'options'  => $this->icon_styles,
						'required' => array('icon_type', '=', 'icon'),
					),
					'icon_color' => array(
						'type'     => 'select',
						'label'    => esc_html__( 'Icon Color', 'mixt-core' ),
						'options'  => $this->icon_colors,
						'class'    => 'color-select basic-colors',
						'std'      => 'auto',
						'required' => array('icon_type', '=', 'icon'),
					),
					'image' => array(
						'type'     => 'media',
						'label'    => esc_html__( 'Icon', 'mixt-core' ),
						'required' => array('icon_type', '=', 'image'),
					),
					'image_style' => array(
						'type'     => 'select',
						'label'    => esc_html__( 'Icon Style', 'mixt-core' ),
						'options'  => $this->image_styles,
						'required' => array('icon_type', '=', 'image'),
					),
					'icon_bg' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Icon Background / Border Color', 'mixt-core' ),
						'options' => $this->colors,
						'class'   => 'color-select basic-colors',
						'std'     => '',
					),
					'icon_size' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Icon Size', 'mixt-core' ),
						'options' => $this->icon_sizes,
						'std'     => '',
					),
					'icon_anim' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Icon Animation', 'mixt-core' ),
						'options' => $this->icon_anims,
					),
					'class' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
					),
				),
				'presets' => array(
					array(
						'icon' => 'fa fa-check',
					),
				),
				'child_title'  => esc_html__( 'List Item', 'mixt-core' ),
				'clone_button' => esc_html__( 'Add Item', 'mixt-core' ),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		// List
		vc_map( array(
			'name'        => esc_html__( 'Icon List', 'mixt-core' ),
			'description' => esc_html__( 'List with icons', 'mixt-core' ),
			'base'        => 'mixt_iconlist',
			'icon'        => 'mixt_element',
			'category'    => 'MIXT',
			'as_parent'   => array('only' => 'mixt_iconlist_item'),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-core' ),
					'group'      => esc_html__( 'Design Options', 'mixt-core' ),
					'param_name' => 'css',
				),
			),
		) );

		// List Item
		vc_map( array(
			'name'        => esc_html__( 'Icon List Item', 'mixt-core' ),
			'base'        => 'mixt_iconlist_item',
			'icon'        => 'mixt_element',
			'category'    => 'MIXT',
			'as_child'    => array('only' => 'mixt_iconlist'),
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Position', 'mixt-core' ),
					'param_name' => 'align',
					'value'      => array(
						esc_html__( 'Left', 'mixt-core' )  => 'left',
						esc_html__( 'Right', 'mixt-core' ) => 'right',
					),
					'std'        => 'left',
				),
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Content', 'mixt-core' ),
					'param_name'  => 'content',
					'admin_label' => true,
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Animation', 'mixt-core' ),
					'param_name' => 'animation',
					'value'      => array_flip($this->animations),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),

				// Icon Tab
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Type', 'mixt-core' ),
					'value'       => array(
						esc_html__( 'Image', 'mixt-core' ) => 'image',
						'Font Awesome' => 'fontawesome',
						'Typicons'     => 'typicons',
						'Entypo'       => 'entypo',
						'Linecons'     => 'linecons',
					),
					'param_name'  => 'icon_type',
					'std'         => 'fontawesome',
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_fontawesome',
					'value'       => 'fa fa-check',
					'settings'    => array( 'emptyIcon' => false ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_fontawesome',
					'settings'    => array( 'emptyIcon' => false ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_typicons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'typicons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'typicons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_linecons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'linecons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'linecons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Style', 'mixt-core' ),
					'param_name' => 'icon_style',
					'value'      => array_flip($this->icon_styles),
					'std'        => 'default',
					'dependency' => array(
						'element' => 'icon_type',
						'value'   => array('fontawesome', 'typicon', 'entypo', 'linecons'),
					),
					'group'      => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Color', 'mixt-core' ),
					'param_name'  => 'icon_color',
					'value'       => array_flip($this->icon_colors),
					'std'         => 'auto',
					'param_holder_class' => 'color-select basic-colors',
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => array('fontawesome', 'typicon', 'entypo', 'linecons'),
					),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'attach_image',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'image',
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'image',
					),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Style', 'mixt-core' ),
					'param_name'  => 'image_style',
					'value'       => array_flip($this->image_styles),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'image',
					),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Background / Border Color', 'mixt-core' ),
					'param_name'  => 'icon_bg',
					'value'       => array_flip($this->colors),
					'std'         => '',
					'param_holder_class' => 'color-select basic-colors',
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Size', 'mixt-core' ),
					'param_name'  => 'icon_size',
					'value'       => array_flip($this->icon_sizes),
					'std'         => '',
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Animation', 'mixt-core' ),
					'param_name' => 'icon_anim',
					'value'      => array_flip($this->icon_anims),
					'group'      => esc_html__( 'Icon', 'mixt-core' ),
				),

				// Design Tab
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-core' ),
					'group'      => esc_html__( 'Design Options', 'mixt-core' ),
					'param_name' => 'css',
				),
			),
		) );
	}

	/**
	 * Render list shortcode
	 */
	public function list_shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'class' => '',
			'css'   => '',
		), $atts );

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_iconlist', $atts );
		}

		extract($args);

		$classes = 'mixt-iconlist mixt-element';
		if ( $class != '' ) $classes .= ' ' . mixt_core_sanitize_html_classes($class);

		return "<ul class='$classes'>" . do_shortcode($content) . '</ul>';
	}

	/**
	 * Render list item shortcode
	 */
	public function item_shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'align'            => 'left',
			'animation'        => '',
			'class'            => '',
			'css'              => '',
			
			'icon'             => '',
			'icon_style'       => 'default',
			'image'            => '',
			'image_style'      => '',
			'icon_color'       => 'auto',
			'icon_bg'          => '',
			'icon_size'        => '',
			'icon_anim'        => '',
			'icon_type'        => 'fontawesome',
			'icon_fontawesome' => 'fa fa-check',
			'icon_typicons'    => '',
			'icon_entypo'      => '',
			'icon_linecons'    => '',
		), $atts );

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_iconlist_item', $atts );
		}

		if ( ! empty($args['animation']) ) $args['class'] .= ' ' . $this->element_animate($args['animation']);

		$args['icon'] = mixt_element_icon_class($args);

		extract($args);

		// Icon
		if ( $icon_type == 'image' ) {
			$img_classes = 'icon mixt-image';
			if ( $icon_size != '' ) $img_classes .= ' ' . $icon_size;
			$img_wrap_classes = 'image-wrap ' . $image_style;
			if ( $icon_bg != '' ) { $img_wrap_classes .= ' ' . $icon_bg; }
			$img_classes = mixt_core_sanitize_html_classes($img_classes);
			$img_wrap_classes = mixt_core_sanitize_html_classes($img_wrap_classes);
			$icon_html = "<div class='$img_classes'><div class='$img_wrap_classes'>" . wp_get_attachment_image($image, 'full') . "</div></div>";
		} else {
			$icon_classes = 'icon mixt-icon ' . $icon_style;
			if ( $icon_size != '' ) $icon_classes .= ' ' . $icon_size;
			if ( $icon_style != 'default' ) {
				if ( $icon_bg != '' ) { $icon_classes .= ' ' . $icon_bg; }
				if ( $icon_anim != '' ) { $icon_classes .= " anim $icon_anim"; }
			}
			$icon_classes = mixt_core_sanitize_html_classes($icon_classes);
			$icon_html = "<span class='$icon_classes'><i class='$icon $icon_color'></i></span>";
		}

		$icon_html = '<div class="icon-wrap">' . mixt_core_clean($icon_html) . '</div>';

		ob_start();
		?>

		<li class="mixt-iconlist-item <?php echo mixt_core_sanitize_html_classes($class); ?>">
			<?php if ( $align == 'left' ) { echo $icon_html; } ?>
			<div class="content-wrap"><?php echo $content; ?></div>
			<?php if ( $align == 'right' ) { echo $icon_html; } ?>
		</li>

		<?php

		return ob_get_clean();
	}
}
new Mixt_Iconlist;

if ( class_exists('WPBakeryShortCodesContainer') ) {
	class WPBakeryShortCode_Mixt_Iconlist extends WPBakeryShortCodesContainer {}
}

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Iconlist_Item extends WPBakeryShortCode {}
}
