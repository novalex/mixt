<?php

/**
 * Pricing Tables
 */
class Mixt_Pricing {

	/** @var array */
	public $colors;

	public function __construct() {
		$this->colors = array_merge( array(
			'' => esc_html__( 'Default', 'mixt-core' ) ),
			mixt_element_assets('colors', 'basic')
		);

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_pricing', array($this, 'table_shortcode'));
		add_shortcode('mixt_pricing_row', array($this, 'row_shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_pricing',
			'title'    => esc_html__( 'Pricing Table', 'mixt-core' ),
			'template' => '[mixt_pricing {{attributes}}]{{nested}}[/mixt_pricing]',
			'params'   => array(
				'plan_name' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Plan Name', 'mixt-core' ),
					'std'   => 'Standard Plan',
				),
				'plan_desc' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Plan Description', 'mixt-core' ),
					'std'   => 'Our standard plan, for individual needs',
				),
				'price' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Price', 'mixt-core' ),
					'desc'  => esc_html__( 'Enter the price and currency for this plan. The currency symbol position will be kept.', 'mixt-core' ),
					'std'   => '$25.99',
				),
				'plan_time' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Plan Duration', 'mixt-core' ),
				),
				'highlight' => array(
					'type'  => 'checkbox',
					'label' => esc_html__( 'Highlighted', 'mixt-core' ),
					'desc'  => esc_html__( 'Check to make this plan stand out from the rest', 'mixt-core' ),
				),
				'scheme' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Color Scheme', 'mixt-core' ),
					'desc'    => esc_html__( 'Light or dark color scheme', 'mixt-core' ),
					'options' => array(
						'light' => esc_html__( 'Light', 'mixt-core' ),
						'dark'  => esc_html__( 'Dark', 'mixt-core' ),
					),
				),
				'color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Header Color', 'mixt-core' ),
					'options' => $this->colors,
					'class'   => 'color-select basic-colors',
				),
				'button' => array(
					'type'  => 'button',
					'label' => esc_html__( 'Button Style', 'mixt-core' ),
				),
				'btn_text' => array(
					'type'    => 'text',
					'label'   => esc_html__( 'Button Text', 'mixt-core' ),
					'desc'    => esc_html__( 'Text for the CTA button', 'mixt-core' ),
					'std'     => 'Buy Now',
				),
				'btn_link' => array(
					'type'    => 'text',
					'label'   => esc_html__( 'Button Link', 'mixt-core' ),
					'desc'    => esc_html__( 'CTA button link (href)', 'mixt-core' ),
					'std'     => 'http://example.com',
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
			'nested' => array(
				'template' => '[mixt_pricing_row]{{content}}[/mixt_pricing_row]',
				'params' => array(
					'content' => array(
						'type'  => 'encoded_textarea',
						'label' => esc_html__( 'Text', 'mixt-core' ),
						'desc'  => esc_html__( 'Table row text, can contain HTML', 'mixt-core' ),
					),
					'class' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
					),
				),
				'child_title'  => esc_html__( 'Table Row', 'mixt-core' ),
				'clone_button' => esc_html__( 'Add Row', 'mixt-core' ),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		// Table
		vc_map( array(
			'name'        => esc_html__( 'Pricing Table', 'mixt-core' ),
			'description' => esc_html__( 'Feature & pricing table', 'mixt-core' ),
			'base'        => 'mixt_pricing',
			'icon'        => 'mixt_pricing',
			'category'    => 'MIXT',
			'as_parent'   => array('only' => 'mixt_pricing_row'),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Plan Name', 'mixt-core' ),
					'param_name'  => 'plan_name',
					'admin_label' => true,
					'std'         => 'Standard Plan',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Plan Description', 'mixt-core' ),
					'param_name' => 'plan_desc',
					'std'        => 'Our standard plan, for individual needs',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Price', 'mixt-core' ),
					'description' => esc_html__( 'Enter the price and currency for this plan. The currency symbol position will be kept.', 'mixt-core' ),
					'param_name'  => 'price',
					'admin_label' => true,
					'std'         => '$25.99',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Plan Duration', 'mixt-core' ),
					'param_name'  => 'plan_time',
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Highlighted', 'mixt-core' ),
					'description' => esc_html__( 'Check to make this plan stand out from the rest', 'mixt-core' ),
					'param_name'  => 'highlight',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Color Scheme', 'mixt-core' ),
					'description' => esc_html__( 'Light or dark color scheme', 'mixt-core' ),
					'value'       => array(
						esc_html__( 'Light', 'mixt-core' ) => 'light',
						esc_html__( 'Dark', 'mixt-core' )  => 'dark',
					),
					'param_name'  => 'scheme',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Header Color', 'mixt-core' ),
					'value'      => array_flip($this->colors),
					'param_name' => 'color',
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'       => 'button',
					'heading'    => esc_html__( 'Button Style', 'mixt-core' ),
					'param_name' => 'button',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Button Text', 'mixt-core' ),
					'description' => esc_html__( 'Text for the CTA button', 'mixt-core' ),
					'param_name'  => 'btn_text',
					'std'         => 'Buy Now',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Button Link', 'mixt-core' ),
					'description' => esc_html__( 'CTA button link (href)', 'mixt-core' ),
					'param_name'  => 'btn_link',
					'std'         => 'http://example.com',
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'bg' => array(
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern'  => 'background-color: {{val}}',
						),
						'color' => array(
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
						),
						'border' => array(
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
						),

						'header-bg' => array(
							'selector' => '.header',
							'label'    => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern'  => 'background-color: {{val}}',
							'group'    => esc_html__( 'Header', 'mixt-core' ),
						),
						'header-color' => array(
							'selector' => '.header',
							'label'    => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
							'group'    => esc_html__( 'Header', 'mixt-core' ),
						),
						'header-border' => array(
							'selector' => '.header',
							'label'    => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
							'group'    => esc_html__( 'Header', 'mixt-core' ),
						),
						'custom' => array(
							'type'     => 'custom',
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Custom CSS', 'mixt-core' ),
						),
					),
					'group'      => 'Styler',
				),

				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name' => 'class',
				),
			),
		) );

		// Feature / row
		vc_map( array(
			'name'        => esc_html__( 'Row', 'mixt-core' ),
			'base'        => 'mixt_pricing_row',
			'icon'        => 'mixt_pricing',
			'category'    => 'MIXT',
			'as_child'    => array('only' => 'mixt_pricing'),
			'params'      => array(
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Text', 'mixt-core' ),
					'description' => esc_html__( 'Table row text, can contain HTML', 'mixt-core' ),
					'param_name'  => 'content',
					'admin_label' => true,
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name' => 'class',
				),
			),
		) );
	}

	/**
	 * Render table shortcode
	 */
	public function table_shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'plan_name' => 'Standard Plan',
			'plan_desc' => 'Our standard plan, for individual needs',
			'price'     => '$25.99',
			'plan_time' => '',
			'highlight' => false,
			'scheme'    => '',
			'color'     => '',
			'btn_text'  => 'Buy Now',
			'btn_link'  => 'http://example.com',
			'button'    => '',
			'styler'    => '',
			'class'     => '',
		), $atts );

		// Styler custom design
		if ( $args['styler'] != '' ) {
			$args['class'] .= mixt_element_styler($args['styler']);
		}

		extract($args);

		$classes = 'pricing-table mixt-pricing mixt-element';
		if ( $highlight ) $classes .= ' highlight';
		if ( $scheme == 'dark' ) $classes .= ' dark';
		if ( $color != '' ) $classes .= ' ' . sanitize_html_class($color);
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);

		if ( $price != '' ) {
			preg_match('/^(\D*)\s*([\d,\.]+)\s*(\D*)$/', $price, $price_arr);
			if ( empty($price_arr[1]) ) {
				$currency = $price_arr[3];
				$currency_position = 'after';
			} else {
				$currency = $price_arr[1];
				$currency_position = 'before';
			}
			$price_amount = explode('.', $price_arr[2]);
		} else {
			$currency_position = null;
			$price_amount = array('', '');
		}

		ob_start();
		?>
		<div class="<?php echo $classes; ?>">
			<ul class="pricing-table-inner mixt-pricing-inner">
				<li class="header">
					<h3 class="plan-name"><?php echo esc_html($plan_name); ?></h3>
					<?php if ( ! empty($plan_desc) ) echo '<p class="plan-desc">' . esc_html($plan_desc) . '</p>'; ?>
					<strong class="price"><?php
						if ( $currency_position == 'before' ) echo "<small class='symbol'>$currency</small>";
						echo $price_amount[0];
						if ( ! empty($price_amount[1]) ) echo "<small class='price-decimal'>{$price_amount[1]}</small>";
						if ( $currency_position == 'after' ) echo "<small class='symbol'>$currency</small>";
						if ( ! empty($plan_time) ) echo "<small class='plan-time'>$plan_time</small>";
					?></strong>
				</li>
				<?php

				// Table Rows
				echo do_shortcode($content);
				?>
				<li class="footer">
					<a href="<?php echo esc_url($btn_link); ?>" class="<?php echo mixt_element_button($button); ?>"><?php echo esc_html($btn_text); ?></a>
				</li>
			</ul>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render table row shortcode
	 */
	public function row_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'class' => '',
		), $atts ) );
		$classes = '';
		if ( empty($content) ) return;
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);
		$content = apply_filters('mixt_unautop', html_entity_decode($content));

		return "<li class='$classes'>$content</li>";
	}
}
new Mixt_Pricing;

if ( class_exists('WPBakeryShortCodesContainer') ) {
	class WPBakeryShortCode_Mixt_Pricing extends WPBakeryShortCodesContainer {}
}

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Pricing_Row extends WPBakeryShortCode {}
}
