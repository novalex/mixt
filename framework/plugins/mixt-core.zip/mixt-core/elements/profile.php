<?php

/**
 * Profile Element
 */
class Mixt_Profile {

	/**
	 * @var array $anims
	 * @var array $colors
	 * @var array $image_styles
	 */
	public $anims, $colors, $image_styles;

	public function __construct() {
		$this->colors = mixt_element_assets('colors', 'basic');
		$this->anims  = array(
			'in' => mixt_element_assets('css-anims', 'trans-in'),
			'out' => mixt_element_assets('css-anims', 'trans-out')
		);
		$this->image_styles = mixt_element_assets('image-styles');

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_profile', array($this, 'shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_profile',
			'title'    => esc_html__( 'Profile', 'mixt-core' ),
			'template' => '[mixt_profile {{attributes}}]{{content}}[/mixt_profile]',
			'params'   => array(
				'name' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Name', 'mixt-core' ),
				),
				'title' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Title / Position', 'mixt-core' ),
				),
				'content' => array(
					'type'  => 'encoded_textarea',
					'label' => esc_html__( 'Description', 'mixt-core' ),
					'desc'  => esc_html__( 'Enter a description about this person (HTML allowed)', 'mixt-core' ),
				),
				'image' => array(
					'type'  => 'media',
					'label' => esc_html__( 'Image', 'mixt-core' ),
				),
				'image_align' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Image Align', 'mixt-core' ),
					'options' => array(
						'align-left'   => esc_html__( 'Left', 'mixt-core' ),
						'align-center' => esc_html__( 'Center', 'mixt-core' ),
						'align-right'  => esc_html__( 'Right', 'mixt-core' ),
					),
					'std' => 'align-center',
				),
				'image_style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Image Style', 'mixt-core' ),
					'options' => $this->image_styles,
				),
				'image_border_color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Border Color', 'mixt-core' ),
					'options' => array_merge(
						array( 'auto' => esc_html__( 'Auto', 'mixt-core' ) ),
						$this->colors
					),
					'class' => 'color-select basic-colors',
					'required' => array('image_style', '=',
						'image-border|image-outline|image-rounded image-border|image-rounded image-outline|image-circle image-border|image-circle image-outline'
					),
				),
				'image_hover_color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Image Hover Color', 'mixt-core' ),
					'options' => $this->colors,
					'class'   => 'color-select basic-colors',
				),
				'image_hover_in' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Hover Animation In', 'mixt-core' ),
					'options' => $this->anims['in'],
				),
				'image_hover_out' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Hover Animation Out', 'mixt-core' ),
					'options' => $this->anims['out'],
				),
				'button' => array(
					'type'  => 'button',
					'label' => esc_html__( 'Button Style', 'mixt-core' ),
				),
				'social' => array(
					'type'  => 'exploded_textarea',
					'label' => esc_html__( 'Social Networks', 'mixt-core' ),
					'desc'  => esc_html__( 'Type in this person\'s social network profiles as url|icon|tooltip, each network separated by a line break (Enter)', 'mixt-core' ),
					'std'   => 'https://facebook.com|fa fa-facebook,https://twitter.com|fa fa-twitter',
				),
				'social_pos' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Social Networks Position', 'mixt-core' ),
					'options' => array(
						'overlay' => esc_html__( 'Image overlay', 'mixt-core' ),
						'header'  => esc_html__( 'Next to name', 'mixt-core' ),
						'bottom'  => esc_html__( 'Bottom', 'mixt-core' ),
					),
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Profile', 'mixt-core' ),
			'description' => esc_html__( 'A person\'s profile', 'mixt-core' ),
			'base'        => 'mixt_profile',
			'icon'        => 'mixt_profile',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Name', 'mixt-core' ),
					'param_name'  => 'name',
					'admin_label' => true,
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Title / Position', 'mixt-core' ),
					'param_name' => 'title',
				),
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Description', 'mixt-core' ),
					'description' => esc_html__( 'Enter a description about this person (HTML allowed)', 'mixt-core' ),
					'param_name'  => 'content',
				),
				array(
					'type'       => 'attach_image',
					'heading'    => esc_html__( 'Image', 'mixt-core' ),
					'param_name' => 'image',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Image Align', 'mixt-core' ),
					'param_name' => 'image_align',
					'value'      => array(
						esc_html__( 'Left', 'mixt-core' )   => 'align-left',
						esc_html__( 'Center', 'mixt-core' ) => 'align-center',
						esc_html__( 'Right', 'mixt-core' )  => 'align-right',
					),
					'std' => 'align-center',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Image Style', 'mixt-core' ),
					'param_name' => 'image_style',
					'value'      => array_flip($this->image_styles),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Border Color', 'mixt-core' ),
					'param_name' => 'image_border_color',
					'value'      => array_merge(
						array( esc_html__( 'Auto', 'mixt-core' ) => 'auto' ),
						array_flip( $this->colors )
					),
					'param_holder_class' => 'color-select basic-colors',
					'dependency' => array(
						'element' => 'image_style',
						'value'   => array(
							'image-border', 'image-outline', 'image-rounded image-border', 'image-rounded image-outline', 'image-circle image-border', 'image-circle image-outline'
						),
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Image Hover Color', 'mixt-core' ),
					'param_name' => 'image_hover_color',
					'value'      => array_flip($this->colors),
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Hover Animation In', 'mixt-core' ),
					'param_name' => 'image_hover_in',
					'value'      => array_flip($this->anims['in']),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Hover Animation Out', 'mixt-core' ),
					'param_name' => 'image_hover_out',
					'value'      => array_flip($this->anims['out']),
				),
				array(
					'type'       => 'button',
					'heading'    => esc_html__( 'Button Style', 'mixt-core' ),
					'param_name' => 'button',
				),
				array(
					'type'        => 'exploded_textarea',
					'heading'     => esc_html__( 'Social Networks', 'mixt-core' ),
					'description' => esc_html__( 'Type in this person\'s social network profiles as url|icon|tooltip, each network separated by a line break (Enter)', 'mixt-core' ),
					'param_name'  => 'social',
					'std'         => 'https://facebook.com|fa fa-facebook,https://twitter.com|fa fa-twitter',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Social Networks Position', 'mixt-core' ),
					'param_name' => 'social_pos',
					'value'      => array(
						esc_html__( 'Image overlay', 'mixt-core' ) => 'overlay',
						esc_html__( 'Next to name', 'mixt-core' )  => 'header',
						esc_html__( 'Bottom', 'mixt-core' )        => 'bottom',
					),
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name' => 'class',
				),
			),
		) );
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'name'               => '',
			'title'              => '',
			'image'              => '',
			'social'             => 'https://facebook.com|fa fa-facebook,https://twitter.com|fa fa-twitter',
			'social_pos'         => 'overlay',
			'class'              => '',
			'button'             => '',
			'image_align'        => 'align-center',
			'image_style'        => 'rounded',
			'image_border_color' => 'auto',
			'image_hover_color'  => key($this->colors),
			'image_hover_in'     => key($this->anims['in']),
			'image_hover_out'    => key($this->anims['out']),
		), $atts ) );

		$classes = 'mixt-profile mixt-element';
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);

		$btn_classes = mixt_element_button($button);

		$has_image = ( ! empty($image) && $image > 0 );
		$content = html_entity_decode($content);

		if ( ! $has_image && $social_pos == 'overlay' ) { $social_pos == 'header'; }

		$social = explode(',', $social);
		$social_links = function($networks, $btn_classes = 'btn btn-default') {
			if ( empty($networks) ) return;
			$btn_classes = mixt_element_sanitize_html_classes($btn_classes);
			$links = '<div class="profile-social btn-group">';
			foreach ( $networks as $network ) {
				$network = explode('|', $network);
				if ( empty($network[0]) ) return;
				$url = esc_url($network[0]);
				$icon = ( empty($network[1]) ) ? 'fa fa-link' : mixt_element_sanitize_html_classes($network[1]);
				$atts = ( empty($network[2]) ) ? '' : 'title="' . esc_attr($network[2]) . '" data-toggle="tooltip"';
				$links .= "<a href='$url' $atts class='$btn_classes' target='_blank'><i class='$icon'></i></a>";
			}
			return $links . '</div>';
		};

		ob_start();
		?>
		
		<div class="<?php echo $classes; ?>">
			<?php if ( $has_image ) {
				$image_classes = 'mixt-image profile-image ' . sanitize_html_class($image_align);
				$image_wrap_classes = 'image-wrap hover-content anim-on-hover ' . mixt_element_sanitize_html_classes( array($image_style, $image_border_color) );
				?>
				<div class="<?php echo $image_classes; ?>">
					<div class="<?php echo $image_wrap_classes; ?>">
					<?php echo wp_get_attachment_image($image, 'full');
					if ( ! empty($social) && $social_pos == 'overlay' ) { ?>
						<div 
							class="on-hover <?php echo sanitize_html_class($image_hover_color); ?>" 
							data-anim-in="<?php echo esc_attr($image_hover_in); ?>" 
							data-anim-out="<?php echo esc_attr($image_hover_out); ?>">
							<div class="inner">
								<?php echo $social_links($social, $btn_classes); ?>
							</div>
						</div>
					<?php } ?>
					</div>
				</div>
			<?php } ?>
			<div class="header clearfix">
				<strong class="name">
					<?php if ( $name != '' ) echo esc_html($name) . '<br>'; ?>
					<small class="color-fade"><?php echo esc_html($title); ?></small>
				</strong>
				<?php if ( $social_pos == 'header' ) echo $social_links($social, $btn_classes); ?>
			</div>

			<?php if ( ! empty($content) || ( $social_pos == 'bottom' && ! empty($social) ) ) { ?>
				<div class="content"><?php
					if ( ! empty($content) ) echo '<p class="desc">' . $content . '</p>';

					if ( $social_pos == 'bottom' ) echo $social_links($social, $btn_classes);
				?></div>
			<?php } ?>
		</div>

		<?php
		return ob_get_clean();
	}
}
new Mixt_Profile;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Profile extends WPBakeryShortCode {}
}
