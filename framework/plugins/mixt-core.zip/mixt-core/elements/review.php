<?php

/**
 * Review Element
 */
class Mixt_Review extends Mixt_Element{

	/**
	 * @var array $colors
	 * @var array $border_colors
	 * @var array $image_styles
	 */
	public $colors, $border_colors, $image_styles;

	public function __construct() {
		parent::__construct();
		
		$this->colors = mixt_element_assets('colors', 'basic');
		$this->border_colors = array_merge(
			array( 'auto' => esc_html__( 'Auto', 'mixt-core' ) ),
			$this->colors
		);
		$this->image_styles = mixt_element_assets('image-styles');

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_review', array($this, 'shortcode'));

		add_action('wp_ajax_mixt_review_styler_parse', array($this, 'parse_styler_ajax'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_review',
			'title'    => esc_html__( 'Review', 'mixt-core' ),
			'template' => '[mixt_review {{attributes}}]{{content}}[/mixt_review]',
			'params'   => array(
				'style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Style', 'mixt-core' ),
					'options' => array(
						'plain'  => esc_html__( 'Plain', 'mixt-core' ),
						'boxed'  => esc_html__( 'Boxed', 'mixt-core' ),
						'bubble' => esc_html__( 'Speech Bubble', 'mixt-core' ),
						'quote'  => esc_html__( 'Quote', 'mixt-core' ),
					),
				),
				'boxed_color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Box Color', 'mixt-core' ),
					'options'  => $this->colors,
					'class'    => 'color-select basic-colors',
					'required' => array('style', '=', 'boxed'),
				),
				'bubble_color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Bubble Color', 'mixt-core' ),
					'options'  => $this->colors,
					'class'    => 'color-select basic-colors',
					'required' => array('style', '=', 'bubble'),
				),
				'layout' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Layout', 'mixt-core' ),
					'options' => array(
						'top'    => esc_html__( 'Author on top, content below', 'mixt-core' ),
						'left'   => esc_html__( 'Author on left, content on right', 'mixt-core' ),
						'right'  => esc_html__( 'Author on right, content on left', 'mixt-core' ),
						'bottom' => esc_html__( 'Author on bottom, content on top', 'mixt-core' ),
					),
				),
				'name' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Name', 'mixt-core' ),
				),
				'title' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Title / Position', 'mixt-core' ),
					'desc'  => esc_html__( 'The reviewer\'s title or position and company', 'mixt-core' ),
				),
				'web' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Web', 'mixt-core' ),
				),
				'image' => array(
					'type'  => 'media',
					'label' => esc_html__( 'Image', 'mixt-core' ),
				),
				'image_halign' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Image Align', 'mixt-core' ),
					'options'  => array(
						'left'  => esc_html__( 'Left', 'mixt-core' ),
						'right' => esc_html__( 'Right', 'mixt-core' ),
					),
					'required' => array('layout', '=', 'top|bottom'),
				),
				'image_valign' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Image Align', 'mixt-core' ),
					'options'  => array(
						'top'    => esc_html__( 'Top', 'mixt-core' ),
						'bottom' => esc_html__( 'Bottom', 'mixt-core' ),
					),
					'required' => array('layout', '=', 'left|right'),
				),
				'image_style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Image Style', 'mixt-core' ),
					'options' => $this->image_styles,
				),
				'image_border_color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Border Color', 'mixt-core' ),
					'options' => $this->border_colors,
					'class' => 'color-select basic-colors',
					'required' => array('image_style', '=',
						'image-border|image-outline|image-rounded image-border|image-rounded image-outline|image-circle image-border|image-circle image-outline'
					),
				),
				'content' => array(
					'type'  => 'encoded_textarea',
					'label' => esc_html__( 'Description', 'mixt-core' ),
					'desc'  => esc_html__( 'The review\'s content', 'mixt-core' ),
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Review', 'mixt-core' ),
			'description' => esc_html__( 'A review or testimonial', 'mixt-core' ),
			'base'        => 'mixt_review',
			'icon'        => 'mixt_review',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Style', 'mixt-core' ),
					'param_name' => 'style',
					'value'      => array(
						esc_html__( 'Plain', 'mixt-core' )         => 'plain',
						esc_html__( 'Boxed', 'mixt-core' )         => 'boxed',
						esc_html__( 'Speech Bubble', 'mixt-core' ) => 'bubble',
						esc_html__( 'Quote', 'mixt-core' )         => 'quote',
					),
					'std'        => 'plain',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Box Color', 'mixt-core' ),
					'param_name' => 'boxed_color',
					'value'      => array_flip($this->colors),
					'param_holder_class' => 'color-select basic-colors',
					'dependency' => array( 'element' => 'style', 'value' => 'boxed' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Bubble Color', 'mixt-core' ),
					'param_name' => 'bubble_color',
					'value'      => array_flip($this->colors),
					'param_holder_class' => 'color-select basic-colors',
					'dependency' => array( 'element' => 'style', 'value' => 'bubble' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Layout', 'mixt-core' ),
					'param_name' => 'layout',
					'value'      => array(
						esc_html__( 'Author on top, content below', 'mixt-core' )     => 'top',
						esc_html__( 'Author on left, content on right', 'mixt-core' ) => 'left',
						esc_html__( 'Author on right, content on left', 'mixt-core' ) => 'right',
						esc_html__( 'Author on bottom, content on top', 'mixt-core' ) => 'bottom',
					),
					'std'        => 'top',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Name', 'mixt-core' ),
					'param_name'  => 'name',
					'admin_label' => true,
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Title, Company', 'mixt-core' ),
					'description' => esc_html__( 'The reviewer\'s title or position and company', 'mixt-core' ),
					'param_name'  => 'title',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Website', 'mixt-core' ),
					'param_name' => 'web',
				),
				array(
					'type'       => 'attach_image',
					'heading'    => esc_html__( 'Image', 'mixt-core' ),
					'param_name' => 'image',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Image Align', 'mixt-core' ),
					'param_name' => 'image_halign',
					'value'      => array(
						esc_html__( 'Left', 'mixt-core' )  => 'left',
						esc_html__( 'Right', 'mixt-core' ) => 'right',
					),
					'std'        => 'left',
					'dependency' => array(
						'element' => 'layout',
						'value'   => array('top', 'bottom'),
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Image Align', 'mixt-core' ),
					'param_name' => 'image_valign',
					'value'      => array(
						esc_html__( 'Top', 'mixt-core' )    => 'top',
						esc_html__( 'Bottom', 'mixt-core' ) => 'bottom',
					),
					'std'        => 'top',
					'dependency' => array(
						'element' => 'layout',
						'value'   => array('left', 'right'),
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Image Style', 'mixt-core' ),
					'param_name' => 'image_style',
					'value'      => array_flip($this->image_styles),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Border Color', 'mixt-core' ),
					'param_name' => 'image_border_color',
					'value'      => array_flip($this->border_colors),
					'param_holder_class' => 'color-select basic-colors',
					'dependency' => array(
						'element' => 'image_style',
						'value'   => array(
							'image-border', 'image-outline',
							'image-rounded image-border', 'image-rounded image-outline',
							'image-circle image-border', 'image-circle image-outline'
						),
					),
				),
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Content', 'mixt-core' ),
					'description' => esc_html__( 'The review\'s content', 'mixt-core' ),
					'param_name'  => 'content',
					'admin_label' => true,
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Animation', 'mixt-core' ),
					'param_name' => 'animation',
					'value'      => array_flip($this->animations),
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name' => 'class',
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'bg' => array(
							'label'   => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern' => 'background-color: {{val}}',
						),
						'color' => array(
							'label'   => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern' => 'color: {{val}}',
						),
						'border' => array(
							'label'   => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern' => 'border-color: {{val}}',
						),
					),
					'group'      => 'Styler',
					'parser'     => 'mixt_review_styler_parse',
				),

				// Design Tab
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-core' ),
					'group'      => esc_html__( 'Design Options', 'mixt-core' ),
					'param_name' => 'css',
				),
			),
		) );
	}

	/**
	 * Parse Styler CSS
	 * 
	 * @param  array  $css CSS split by selector and property
	 * @return string Parsed CSS string
	 */
	public function parse_styler_css( $css = '' ) {
		if ( empty($css) ) return '';
		$css = mixt_styler_parse($css);
		$parsed_css = $rules = '';

		$selector = $css['selector'];
		if ( ! empty($css['rules']['.'.$selector]) ) {
			$rules = $css['rules']['.'.$selector];
			unset($css);
		}

		if ( ! empty($rules['background-color']) ) {
			$parsed_css .= ".$selector.boxed, .$selector.bubble .review-content, .$selector.bubble .review-content:before { background-color: {$rules['background-color']} !important; }\n";
		}
		if ( ! empty($rules['border-color']) ) {
			$parsed_css .= ".$selector.boxed, .$selector.bubble .review-content { border-color: {$rules['border-color']} !important; }\n";
		}
		if ( ! empty($rules['color']) ) {
			$parsed_css .= ".$selector .review-content { color: {$rules['color']} !important; }\n";
		}

		return $parsed_css;
	}

	/**
	 * Parse Styler CSS and return JSON data (used for injecting CSS when editing elements)
	 */
	public function parse_styler_ajax() {
		$css = $_POST['data'];
		echo json_encode($this->parse_styler_css($css));
		die();
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'style'              => 'plain',
			'boxed_color'        => key($this->colors),
			'bubble_color'       => key($this->colors),
			'layout'             => 'top',
			'name'               => '',
			'title'              => '',
			'web'                => '',
			'image'              => '',
			'image_halign'       => 'left',
			'image_valign'       => 'top',
			'image_style'        => 'rounded',
			'image_border_color' => 'auto',
			'animation'          => '',
			'class'              => '',

			'styler'             => '',

			'css'                => '',
		), $atts );

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_review', $atts );
		}

		// Styler custom design
		if ( $args['styler'] ) {
			$args['class'] .= mixt_element_styler($args['styler'], array($this, 'parse_styler_css'));
		}

		extract($args);

		$classes = 'mixt-review mixt-element ' . $style;
		if ( $style == 'boxed' ) $classes .= ' ' . $boxed_color;
		if ( $layout == 'top' || $layout == 'bottom' ) {
			$horizontal = true;
			$classes .= ' layout-h';
		} else {
			$horizontal = false;
			$classes .= ' layout-v';
		}
		if ( ! empty($animation) ) $classes .= ' ' . $this->element_animate($animation);
		if ( $class != '' ) $classes .= ' ' . $class;
		$classes = mixt_element_sanitize_html_classes($classes);

		$content_classes = 'review-content';
		if ( $style == 'bubble' ) $content_classes .= ' ' . sanitize_html_class($bubble_color);

		$content_html = "<div class='$content_classes'>";
		if ( $style == 'quote' ) {
			$content_html .= '<blockquote>' . html_entity_decode($content) . '</blockquote>';
		} else {
			$content_html .= '<p>' . html_entity_decode($content) . '</p>';
		}
		$content_html .= '</div>';

		$author_image_html = '';
		if ( ! empty($image) && $image > 0 ) {
			$image_wrap_class = 'image-wrap ' . mixt_element_sanitize_html_classes( array($image_style, $image_border_color) );
			$author_image_html = '<div class="mixt-image author-image">' .
				"<div class='$image_wrap_class'>" .
					wp_get_attachment_image($image, 'full') .
				'</div>' .
			'</div>';
		}
		$image_before_info = ( ( $horizontal && $image_halign == 'left' ) || ( ! $horizontal && $image_valign == 'top' ) ) ? true : false;

		$author_html = '<div class="review-author">';
			if ( $image_before_info ) { $author_html .= $author_image_html; }
			$author_html .= '<div class="author-info">';
				if ( $name != '' ) { $author_html .= '<strong class="name">' . esc_html($name) . '</strong>'; }
				if ( $title != '' ) { $author_html .= '<small class="title color-fade">' . esc_html($title) . '</small>'; }
				if ( filter_var($web, FILTER_VALIDATE_URL) !== false ) {
					$author_html .= '<a href="' . $web . '" target="_blank" class="website">' . str_replace(array('http://', 'https://', 'www.'), '', $web) . '</a>';
				}
			$author_html .= '</div>';
			if ( ! $image_before_info ) { $author_html .= $author_image_html; }
		$author_html .= '</div>';

		ob_start();
		?>
		
		<div class="<?php echo $classes; ?>">
			<?php
			if ( $layout == 'top' || $layout == 'left' ) { echo $author_html; }
			echo apply_filters('mixt_unautop', $content_html);
			if ( $layout == 'right' || $layout == 'bottom' ) { echo $author_html; }
			?>
		</div>

		<?php
		return ob_get_clean();
	}
}
new Mixt_Review;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Review extends WPBakeryShortCode {}
}
