<?php

/**
 * Social Icons Element
 */
class Mixt_Social {

	/** @var array */
	public $profiles;

	public function __construct() {
		$this->profiles = $this->profiles_array();

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_social', array($this, 'shortcode'));
	}

	/**
	 * Get array of configured social profiles or, if none are found, return preset ones
	 */
	public function profiles_array() {
		global $mixt_opt;
		$array = $profiles = array();
		if ( ! empty($mixt_opt['social-profiles']) ) {
			$profiles = $mixt_opt['social-profiles'];
		} else if ( function_exists('mixt_preset_social_profiles') ) {
			$profiles = mixt_preset_social_profiles();
		}
		foreach ( $profiles as $key => $profile ) { $array[$key] = $profile['name']; }
		return $array;
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_social',
			'title'    => esc_html__( 'Social', 'mixt-core' ),
			'template' => '[mixt_social {{attributes}}]',
			'params'   => array(
				'style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Style', 'mixt-core' ),
					'options' => array(
						'plain'   => esc_html__( 'Plain', 'mixt-core' ),
						'buttons' => esc_html__( 'Buttons', 'mixt-core' ),
						'group'   => esc_html__( 'Button Group', 'mixt-core' ),
						'nav'     => esc_html__( 'Nav Menu', 'mixt-core' ),
					),
				),
				'button' => array(
					'type'     => 'button',
					'label'    => esc_html__( 'Button Style', 'mixt-core' ),
					'required' => array( 'style', '=', 'buttons|group' ),
				),
				'hover' => array(
					'type' => 'select',
					'label' => esc_html__( 'Hover Color', 'mixt-core' ),
					'options' => array(
						'icon' => esc_html__( 'Icon', 'mixt-core' ),
						'bg'   => esc_html__( 'Background', 'mixt-core' ),
						'none' => esc_html__( 'None', 'mixt-core' ),
					),
				),
				'profiles' => array(
					'type'    => 'checkbox',
					'label'   => esc_html_x( 'Profiles', 'social', 'mixt-core' ),
					'options' => $this->profiles,
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Social Icons', 'mixt-core' ),
			'description' => esc_html__( 'Social network profile icons', 'mixt-core' ),
			'base'        => 'mixt_social',
			'icon'        => 'mixt_social',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Style', 'mixt-core' ),
					'param_name' => 'style',
					'value'      => array(
						esc_html__( 'Plain', 'mixt-core' )        => 'plain',
						esc_html__( 'Buttons', 'mixt-core' )      => 'buttons',
						esc_html__( 'Button Group', 'mixt-core' ) => 'group',
						esc_html__( 'Nav Menu', 'mixt-core' )     => 'nav',
					),
					'std'        => 'buttons',
				),
				array(
					'type'       => 'button',
					'heading'    => esc_html__( 'Button Style', 'mixt-core' ),
					'param_name' => 'button',
					'dependency' => array(
						'element' => 'style',
						'value'   => array('buttons', 'group')
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Hover Color', 'mixt-core' ),
					'param_name'  => 'hover',
					'value'       => array(
						esc_html__( 'Icon', 'mixt-core' )       => 'icon',
						esc_html__( 'Background', 'mixt-core' ) => 'bg',
						esc_html__( 'None', 'mixt-core' )       => 'none',
					),
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html_x( 'Profiles', 'social', 'mixt-core' ),
					'param_name'  => 'profiles',
					'admin_label' => true,
					'value'       => array_flip($this->profiles),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-core' ),
					'group'      => esc_html__( 'Design Options', 'mixt-core' ),
					'param_name' => 'css',
				),
			),
		) );
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts ) {
		$args = shortcode_atts( array(
			'style'    => 'buttons',
			'hover'    => 'icon',
			'profiles' => '',
			'button'   => '',
			'class'    => '',
			'css'      => '',
		), $atts );

		if ( ! defined('MIXT_VERSION') ) return MIXTEL_DISABLED;

		$args['class'] = 'mixt-social mixt-element ' . mixt_element_sanitize_html_classes($args['class']);
		$args['type'] = 'networks';
		if ( $args['style'] == 'plain' && $args['hover'] == 'bg' ) $args['hover'] = 'icon';

		$args = array_merge($args, mixt_element_button($args['button'], 'value'));

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_social', $atts );
		}

		if ( ! empty($args['profiles']) ) {
			global $mixt_opt;
			$profiles = array();
			$sel_profiles = explode(',', $args['profiles']);
			$set_profiles = ( ! empty($mixt_opt['social-profiles']) ) ? $mixt_opt['social-profiles'] : mixt_preset_social_profiles();
			foreach ( $set_profiles as $key => $profile ) {
				if ( in_array($key, $sel_profiles) ) $profiles[$key] = $profile;
			}
			$args['profiles'] = $profiles;
		}

		return mixt_social_profiles(false, $args);
	}
}
new Mixt_Social;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Social extends WPBakeryShortCode {}
}
