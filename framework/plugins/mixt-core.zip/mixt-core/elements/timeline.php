<?php

/**
 * Timeline Element
 */
class Mixt_Timeline extends Mixt_Element {

	/**
	 * @var array $colors
	 * @var array $icon_styles
	 * @var array $icon_colors
	 */
	public $colors, $icon_styles, $icon_colors;
	
	function __construct() {
		parent::__construct();

		$this->colors = mixt_element_assets('colors', 'basic');
		$this->icon_styles = mixt_element_assets('icon-styles');
		$this->icon_colors = array_merge(
			array( 'auto' => esc_html__( 'Auto', 'mixt-core' ) ),
			$this->colors
		);

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_timeline', array($this, 'timeline_shortcode'));
		add_shortcode('mixt_timeline_block', array($this, 'timeline_block_shortcode'));

		add_action('wp_ajax_mixt_timeline_styler_parse', array($this, 'parse_styler_ajax'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_timeline',
			'title'    => esc_html__( 'Timeline', 'mixt-core' ),
			'template' => '[mixt_timeline {{attributes}}]{{nested}}[/mixt_timeline]',
			'params'   => array(
				'type' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Type', 'mixt-core' ),
					'desc'    => esc_html__( 'Double sided or single sided timeline', 'mixt-core' ),
					'options' => array(
						'double' => esc_html__( 'Double sided', 'mixt-core' ),
						'left'   => esc_html__( 'Left sided', 'mixt-core' ),
						'right'  => esc_html__( 'Right sided', 'mixt-core' ),
					),
				),
				'small_align' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Small Screen Align', 'mixt-core' ),
					'desc'    => esc_html__( 'Alignment for small screens, when collapsed into a single column', 'mixt-core' ),
					'options' => array(
						'left'  => esc_html__( 'Left', 'mixt-core' ),
						'right' => esc_html__( 'Right', 'mixt-core' ),
					),
					'required' => array('type', '=', 'double'),
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
				),
			),
			'nested' => array(
				'template' => '[mixt_timeline_block {{attributes}}]{{content}}[/mixt_timeline_block]',
				'params' => array(
					'style' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Style', 'mixt-core' ),
						'options' => array(
							'plain'  => esc_html__( 'Plain', 'mixt-core' ),
							'boxed'  => esc_html__( 'Boxed', 'mixt-core' ),
							'bubble' => esc_html__( 'Bubble', 'mixt-core' ),
						),
					),
					'color' => array(
						'type'     => 'select',
						'label'    => esc_html__( 'Color', 'mixt-core' ),
						'options'  => $this->colors,
						'class'    => 'color-select basic-colors',
						'std'      => 'grey',
						'required' => array('style', '=', 'boxed|bubble'),
					),
					'align' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Alignment', 'mixt-core' ),
						'desc'    => esc_html__( 'Display this block to the left or right of the timeline. "Auto" to alternate.', 'mixt-core' ),
						'options' => array(
							'auto'  => esc_html__( 'Auto', 'mixt-core' ),
							'left'  => esc_html__( 'Left', 'mixt-core' ),
							'right' => esc_html__( 'Right', 'mixt-core' ),
						),
					),
					'icon' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Anchor Icon', 'mixt-core' ),
						'std'   => 'fa fa-circle-o',
					),
					'icon_style' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Anchor Style', 'mixt-core' ),
						'options' => $this->icon_styles,
						'std'     => 'icon-solid icon-rounded',
					),
					'icon_color' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Anchor Icon Color', 'mixt-core' ),
						'options' => $this->icon_colors,
						'class'   => 'color-select basic-colors',
						'std'     => 'auto',
					),
					'icon_bg' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Anchor Background / Border Color', 'mixt-core' ),
						'options' => $this->colors,
						'class'   => 'color-select basic-colors',
						'std'     => 'accent',
					),
					'icon_anim' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Icon Animation', 'mixt-core' ),
						'options' => $this->icon_anims,
					),
					'content' => array(
						'type'  => 'encoded_textarea',
						'label' => esc_html__( 'Content', 'mixt-core' ),
						'desc'  => esc_html__( 'The block\'s content (HTML and shortcodes allowed)', 'mixt-core' ),
					),
					'animation' => array(
						'type'    => 'select',
						'label'   => esc_html__( 'Animation', 'mixt-core' ),
						'desc'    => esc_html__( 'Apply an animation to the element when it becomes visible', 'mixt-core' ),
						'options' => $this->animations,
					),
					'class' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Extra Classes', 'mixt-core' ),
					),
				),
				'child_title'  => esc_html__( 'Timeline Block', 'mixt-core' ),
				'clone_button' => esc_html__( 'Add Block', 'mixt-core' ),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		// Timeline
		vc_map( array(
			'name'        => esc_html__( 'Timeline', 'mixt-core' ),
			'description' => esc_html__( 'A timeline-type layout', 'mixt-core' ),
			'base'        => 'mixt_timeline',
			'icon'        => 'mixt_timeline',
			'category'    => 'MIXT',
			'as_parent'   => array('only' => 'mixt_timeline_block'),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Type', 'mixt-core' ),
					'description' => esc_html__( 'Double sided or single sided timeline', 'mixt-core' ),
					'param_name'  => 'type',
					'value'       => array(
						esc_html__( 'Double sided', 'mixt-core' ) => 'double',
						esc_html__( 'Left sided', 'mixt-core' )   => 'left',
						esc_html__( 'Right sided', 'mixt-core' )  => 'right',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Small Screen Align', 'mixt-core' ),
					'description' => esc_html__( 'Alignment for small screens, when collapsed into a single column', 'mixt-core' ),
					'param_name'  => 'small_align',
					'value'       => array(
						esc_html__( 'Left', 'mixt-core' )   => 'left',
						esc_html__( 'Right', 'mixt-core' )  => 'right',
					),
					'dependency' => array( 'element' => 'type', 'value' => 'double' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name'  => 'class',
				),
			),
		) );

		// Timeline Block
		vc_map( array(
			'name'        => esc_html__( 'Timeline Block', 'mixt-core' ),
			'base'        => 'mixt_timeline_block',
			'icon'        => 'mixt_timeline',
			'category'    => 'MIXT',
			'as_child'    => array('only' => 'mixt_timeline'),
			'as_parent'   => array('except' => 'mixt_timeline, mixt_timeline_block'),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Style', 'mixt-core' ),
					'param_name' => 'style',
					'value'      => array(
						esc_html__( 'Plain', 'mixt-core' )  => 'plain',
						esc_html__( 'Boxed', 'mixt-core' )  => 'boxed',
						esc_html__( 'Bubble', 'mixt-core' ) => 'bubble',
					),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Color', 'mixt-core' ),
					'param_name' => 'color',
					'value'      => array_flip($this->colors),
					'std'        => 'grey',
					'dependency' => array(
						'element' => 'style',
						'value'   => array( 'boxed', 'bubble' ),
					),
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Alignment', 'mixt-core' ),
					'description' => esc_html__( 'Display this block to the left or right of the timeline. "Auto" to alternate.', 'mixt-core' ),
					'param_name'  => 'align',
					'value'       => array(
						esc_html__( 'Auto', 'mixt-core' )   => 'auto',
						esc_html__( 'Left', 'mixt-core' )   => 'left',
						esc_html__( 'Right', 'mixt-core' )  => 'right',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Anchor Icon Type', 'mixt-core' ),
					'value'       => array(
						'Font Awesome' => 'fontawesome',
						'Typicons'     => 'typicons',
						'Entypo'       => 'entypo',
						'Linecons'     => 'linecons',
					),
					'param_name'  => 'icon_type',
					'std'         => 'fontawesome',
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Anchor Icon', 'mixt-core' ),
					'param_name'  => 'icon_fontawesome',
					'value'       => 'fa fa-circle-o',
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_fontawesome',
					'settings'    => array( 'emptyIcon' => false ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-core' ),
					'param_name'  => 'icon_typicons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'typicons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'typicons' ),
					'group'       => esc_html__( 'Icon', 'mixt-core' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Anchor Icon', 'mixt-core' ),
					'param_name'  => 'icon_linecons',
					'settings'    => array(
						'type'      => 'linecons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'linecons' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Anchor Style', 'mixt-core' ),
					'param_name' => 'icon_style',
					'value'      => array_flip($this->icon_styles),
					'std'        => 'icon-solid icon-rounded',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Anchor Icon Color', 'mixt-core' ),
					'param_name'  => 'icon_color',
					'value'       => array_flip($this->icon_colors),
					'std'         => 'auto',
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Anchor Background / Border Color', 'mixt-core' ),
					'param_name'  => 'icon_bg',
					'value'       => array_flip($this->colors),
					'std'         => 'accent',
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Animation', 'mixt-core' ),
					'param_name' => 'icon_anim',
					'value'      => array_flip($this->icon_anims),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Animation', 'mixt-core' ),
					'description' => esc_html__( 'Apply an animation to the element when it becomes visible', 'mixt-core' ),
					'param_name'  => 'animation',
					'value'       => array_flip($this->animations),
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-core' ),
					'param_name' => 'class',
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'bg' => array(
							'selector' => '.content',
							'label'    => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern'  => 'background-color: {{val}}',
						),
						'color' => array(
							'selector' => '.content',
							'label'    => esc_html__( 'Text Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
						),
						'border' => array(
							'selector' => '.content',
							'label'    => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
						),

						'anchor-bg' => array(
							'selector' => '.anchor',
							'label'    => esc_html__( 'Background Color', 'mixt-core' ),
							'pattern'  => 'background-color: {{val}}',
							'group'    => esc_html__( 'Anchor', 'mixt-core' ),
						),
						'anchor-color' => array(
							'selector' => '.anchor',
							'label'    => esc_html__( 'Icon Color', 'mixt-core' ),
							'pattern'  => 'color: {{val}}',
							'group'    => esc_html__( 'Anchor', 'mixt-core' ),
						),
						'anchor-border' => array(
							'selector' => '.anchor',
							'label'    => esc_html__( 'Border Color', 'mixt-core' ),
							'pattern'  => 'border-color: {{val}}',
							'group'    => esc_html__( 'Anchor', 'mixt-core' ),
						),

						'custom' => array(
							'type'  => 'custom',
							'label' => esc_html__( 'Custom CSS', 'mixt-core' ),
						),
					),
					'group'      => 'Styler',
					'parser'     => 'mixt_timeline_styler_parse',
				),
			),
		) );
	}

	/**
	 * Parse Styler CSS
	 * 
	 * @param  array  $css CSS split by selector and property
	 * @return string Parsed CSS string
	 */
	public function parse_styler_css( $css = '' ) {
		if ( empty($css) ) return '';
		$css = mixt_styler_parse($css);
		$parsed_css = $content_props = $anchor_props = '';

		$selector = $css['selector'];

		if ( ! empty($css['rules']['.content']['background-color']) ) {
			$parsed_css .= ".$selector .content, .$selector .content.bubble:before { background-color: {$css['rules']['.content']['background-color']} !important; }\n";
		}
		if ( ! empty($css['rules']['.content']['border-color']) ) {
			$content_props .= "border-color: {$css['rules']['.content']['border-color']} !important; ";
		}
		if ( ! empty($css['rules']['.content']['color']) ) {
			$content_props .= "color: {$css['rules']['.content']['color']} !important; ";
		}
		if ( $content_props != '' ) {
			$parsed_css .= ".$selector .content { $content_props }\n";
		}

		if ( ! empty($css['rules']['.anchor']['background-color']) ) {
			$anchor_props .= "background-color: {$css['rules']['.anchor']['background-color']} !important; ";
		}
		if ( ! empty($css['rules']['.anchor']['border-color']) ) {
			$anchor_props .= "border-color: {$css['rules']['.anchor']['border-color']} !important; ";
		}
		if ( ! empty($css['rules']['.anchor']['color']) ) {
			$anchor_props .= "color: {$css['rules']['.anchor']['color']} !important; ";
		}
		if ( $anchor_props != '' ) {
			$parsed_css .= ".$selector .anchor { $anchor_props }\n";
		}

		return $parsed_css;
	}

	/**
	 * Parse Styler CSS and return JSON data (used for injecting CSS when editing elements)
	 */
	public function parse_styler_ajax() {
		$css = $_POST['data'];
		echo json_encode($this->parse_styler_css($css));
		die();
	}

	/**
	 * Render timeline shortcode
	 */
	public function timeline_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'type'        => 'double',
			'small_align' => 'left',
			'class'       => '',
		), $atts ) );

		$classes = 'mixt-timeline mixt-element timeline-' . $type;
		if ( $type == 'double' ) $classes .= ' single-' . $small_align;
		if ( $class != '' ) $classes .= ' ' . $class;
		$classes = mixt_element_sanitize_html_classes($classes);

		return "<div class='$classes'>" . do_shortcode($content) . '</div>';
	}

	/**
	 * Render timeline block shortcode
	 */
	public function timeline_block_shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'style'            => 'plain',
			'color'            => 'grey',
			'align'            => 'auto',

			'icon'             => '',
			'icon_type'        => 'fontawesome',
			'icon_fontawesome' => 'fa fa-circle-o',
			'icon_typicons'    => '',
			'icon_entypo'      => '',
			'icon_linecons'    => '',
			'icon_style'       => 'icon-solid icon-rounded',
			'icon_color'       => 'auto',
			'icon_bg'          => 'accent',
			'icon_anim'        => '',

			'animation'        => '',
			'class'            => '',
			'styler'           => '',
		), $atts );

		$args['icon'] = mixt_element_icon_class($args);

		// Styler custom design
		if ( ! empty($args['styler']) ) {
			$args['class'] .= mixt_element_styler($args['styler'], array($this, 'parse_styler_css'));
		}

		extract($args);

		$classes = "timeline-block align-$align icon-cont";
		if ( $class != '' ) $classes .= ' ' . $class;
		$classes = mixt_element_sanitize_html_classes($classes);

		$icon_classes = "anchor mixt-icon $icon_bg $icon_style";
		if ( $icon_anim != '' && $icon_style != 'default' ) { $icon_classes .= " anim $icon_anim"; }
		$icon_classes = mixt_element_sanitize_html_classes($icon_classes);

		$content = html_entity_decode($content);
		$content_classes = "content $style";
		if ( $style != 'plain' ) $content_classes .= ' ' . $color;
		if ( ! empty($animation) ) $content_classes .= ' ' . $this->element_animate($animation);
		$content_classes = mixt_element_sanitize_html_classes($content_classes);

		return "<div class='$classes'>" .
				   "<span class='$icon_classes'><i class='$icon $icon_color'></i></span>" .
				   "<div class='$content_classes'>" .
					   do_shortcode($content) .
				   '</div>' .
			   '</div>';
	}
}
new Mixt_Timeline;

if ( class_exists('WPBakeryShortCodesContainer') ) {
	class WPBakeryShortCode_Mixt_Timeline extends WPBakeryShortCodesContainer {}
}

if ( class_exists('WPBakeryShortCodesContainer') ) {
	class WPBakeryShortCode_Mixt_Timeline_Block extends WPBakeryShortCodesContainer {}
}
