<?php

defined('ABSPATH') or die('You are not supposed to do that.'); // No Direct Access

/**
 * Add admin pages for easy access to theme information and options
 */
class Mixt_Admin_Menu_Pages extends Mixt_Admin_Menu {
	public function __construct() {
		add_action('admin_menu', array($this, 'admin_menu_pages'), 1);
	}

	public function admin_menu_pages() {
		// Main Menu
		add_menu_page('MIXT', 'MIXT', $this->capability, 'mixt-admin', '', MIXT_URI . '/assets/img/admin-menu-icon.png', '59.6498');

		// About Page
		add_submenu_page('mixt-admin', esc_html__( 'About MIXT', 'mixt-core' ), esc_html__( 'About', 'mixt-core' ), $this->capability, 'mixt-admin', array($this, 'about_screen'));

		// Status Page
		add_submenu_page('mixt-admin', esc_html__( 'Status', 'mixt-core' ), esc_html__( 'Status', 'mixt-core' ), $this->capability, 'mixt-status', array($this, 'status_screen'));
	}
}
new Mixt_Admin_Menu_Pages;