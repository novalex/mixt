<?php

// Element Common Assets & Functions

/**
 * Parse styler properties and enqueue CSS
 * 
 * @param  string   $css
 * @param  callback $callback Custom function to parse Styler CSS
 * @return string   CSS class name
 */
function mixt_element_styler( $css, $callback = null ) {
	preg_match('/\.(styler-.{7})/', $css, $matches);
	$selector = $matches[1];

	if ( is_callable($callback) ) {
		$parsed_css = call_user_func($callback, $css);
	} else {
		$parsed_css = str_replace(array('{', '|', ';'), array(' { ', "\n", ' !important; '), $css);
	}

	if ( class_exists('Mixt_DCSS') && strpos(Mixt_DCSS::$body_css, $selector) === false ) {
		Mixt_DCSS::$body_css .= "$parsed_css";
	}

	return $selector;
}


/**
 * Parse a Styler CSS string and return array of rules and selectors
 * 
 * @param  string $css
 * @return array
 */
function mixt_styler_parse( $css ) {
	$css = str_replace(': ', ':', $css);

	// Get selector
	preg_match('/\.(styler-.{7})/', $css, $matches);
	$selector = $matches[1];

	// Parse top-level selectors
	preg_match_all('/([^\s]+?){(.*?)}/', $css, $matches);
	if ( empty($matches[1]) || empty($matches[2]) ) return null;
	$rules = array_combine($matches[1], $matches[2]);

	// Parse properties and attributes
	foreach ( $rules as $sel => $props ) {
		preg_match_all('/([^\s]+?):(.+?);/', $props, $matches);
		$rules[$sel] = array_combine($matches[1], $matches[2]);
		$rules[$sel]['raw'] = $props;
	}

	return array(
		'selector' => $selector,
		'rules' => $rules,
	);
}


/**
 * Parse button attributes
 * 
 * @param string $atts
 * @param string $return return parsed values or classes
 */
function mixt_element_button( $atts, $return = 'class' ) {
	$values = array(
		'type'  => '',
		'color' => 'default',
		'size'  => '',
		'anim'  => '',
	);
	preg_match_all('/([^,]+):([^,]+)/', $atts, $matches);
	if ( ! empty($matches[1]) ) {
		$values = wp_parse_args(array_combine($matches[1], $matches[2]), $values);
	}

	if ( $return == 'value' ) {
		return $values;
	} else {
		$classes = 'btn';
		foreach ( $values as $att => $value ) {
			if ( empty($value) ) continue;
			
			switch ( $att ) {
				case 'type':
				case 'color':
				case 'anim':
					$classes .= ' btn-' . $value;
					break;
				default:
					$classes .= ' ' . $value;
					break;
			}
		}
		return mixt_element_sanitize_html_classes( trim($classes) );
	}
}


/**
 * Element icon class
 */
function mixt_element_icon_class( $args ) {
	if ( $args['icon'] == '' && $args['icon_type'] != 'icon' && $args['icon_type'] != 'image' ) {
		global $mixt_opt;
		$icon = $args["icon_{$args['icon_type']}"];
		$icon_fonts = ( ! empty($mixt_opt['icon-fonts']) ) ? $mixt_opt['icon-fonts'] : array();
		if ( array_key_exists($args['icon_type'], $icon_fonts) && $icon_fonts[$args['icon_type']] ) {
			if ( $args['icon_type'] == 'linecons' ) {
				$icon = str_replace(array('vc_li ', 'vc_li-'), array('icon-li ', 'li_'), $icon);
			}
		} else if ( function_exists('vc_icon_element_fonts_enqueue') ) {
			vc_icon_element_fonts_enqueue($args['icon_type']);
		}
	} else {
		$icon = $args['icon'];
	}
	return mixt_element_sanitize_html_classes($icon);
}


/**
 * Retreive assets by group and subgroup
 */
function mixt_element_assets( $group, $subgroup = false ) {
	$assets = array(
		'icon-styles' => array(
			'default'      => esc_html__( 'Default', 'mixt-core' ),
			'icon-solid'   => esc_html__( 'Solid', 'mixt-core' ),
			'icon-outline' => esc_html__( 'Outlined', 'mixt-core' ),
			'icon-solid icon-rounded'   => esc_html__( 'Rounded', 'mixt-core' ),
			'icon-outline icon-rounded' => esc_html__( 'Rounded outline', 'mixt-core' ),
			'icon-solid icon-circle'    => esc_html__( 'Circle', 'mixt-core' ),
			'icon-outline icon-circle'  => esc_html__( 'Circle outline', 'mixt-core' ),
		),
		'icon-sizes' => array(
			''        => esc_html__( 'Normal', 'mixt-core' ),
			'icon-sm' => esc_html__( 'Small', 'mixt-core' ),
			'icon-lg' => esc_html__( 'Large', 'mixt-core' ),
			'icon-xl' => esc_html__( 'Extra Large', 'mixt-core' ),
		),

		'row-separators' => array(
			''                 => esc_html__( 'None', 'mixt-core' ),
			'curve'            => esc_html__( 'Curve', 'mixt-core' ),
			'curve-inv'        => esc_html__( 'Curve (inverted)', 'mixt-core' ),
			'circle'           => esc_html__( 'Circle', 'mixt-core' ),
			'cricle-inv'       => esc_html__( 'Circle (inverted)', 'mixt-core' ),
			'triangle'         => esc_html__( 'Triangle', 'mixt-core' ),
			'triangle-inv'     => esc_html__( 'Triangle (inverted)', 'mixt-core' ),
			'big-triangle'     => esc_html__( 'Big Triangle', 'mixt-core' ),
			'big-triangle-inv' => esc_html__( 'Big Triangle (inverted)', 'mixt-core' ),
		),
	);

	if ( ! isset($assets[$group]) ) {
		if ( defined('MIXT_VERSION') ) {
			switch ($group) {
				case 'css-anims':
					return mixt_css_anims($subgroup);
					break;
				case 'icon-anims':
					return mixt_icon_anims();
					break;
				default:
					return mixt_get_assets($group, $subgroup);
			}
		} else {
			return array();
		}
	} else {
		return $assets[$group];
	}
}


/**
 * Wrapper function to enqueue plugins
 */
function mixt_element_enqueue_plugin( $plugin ) {
	if ( function_exists('mixt_enqueue_plugin') ) {
		mixt_enqueue_plugin($plugin);
	}
	return;
}


/**
 * Wrapper function to get icons
 */
function mixt_element_get_icon( $icon, $markup = true ) {
	if ( function_exists('mixt_get_icon') ) {
		return mixt_get_icon($icon, $markup);
	}
	return;
}


/**
 * Wrapper function to sanitize HTML classes
 */
function mixt_element_sanitize_html_classes( $cls, $fallback = null ) {
	if ( function_exists('mixt_sanitize_html_classes') ) {
		return mixt_sanitize_html_classes($cls, $fallback);
	} else {
		return ( is_array($cls) ) ? implode(' ', $cls) : $cls;
	}
}


/**
 * Output row separator
 */
function mixt_row_separator( $type = 'triangle', $color = '', $icon = '' ) {
	$cont_class = $svg_fill = '';
	if ( $color != '' ) {
		$svg_fill = 'fill="' . esc_attr($color) . '"';
	} else {
		$cont_class .= 'no-fill';
	}
	$svg_atts = 'xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none"';

	$cont_class .= ' ' . sanitize_html_class($type);

	$output = '';

	$output .= "<div class='mixt-row-separator $cont_class'>";
		// Multi-Part Separators
		if ( $type == 'circle-inv' || $type == 'triangle-inv' ) {
			$output .= "<svg class='sep-left' $svg_fill $svg_atts><rect width='100' height='100' /></svg>";
			$output .= "<svg class='sep-center' $svg_fill $svg_atts>";
				if ( $type == 'circle-inv' ) {
					$output .= '<path d="M 0 0 a 50.01 100 0 0 0 99.9 0 L 100 100 0 100 z" /></svg>';
				} else {
					$output .= '<polygon points="0 0, 50 99, 100 0, 100 100, 0 100" /></svg>';
				}
			$output .= "<svg class='sep-right' $svg_fill $svg_atts><rect width='100' height='100' /></svg>";
		// Single-Part Separators
		} else {
			$output .= "<svg $svg_fill $svg_atts>";
			switch($type) {
				case 'curve':
					$output .= '<path d="M 0 0 q 50 200 100 0 L 100 0 z" />';
					break;
				case 'curve-inv':
					$output .= '<path d="M 0 0 q 50 200 100 0 L 100 100 0 100 z" />';
					break;
				case 'circle':
					$output .= '<circle cx="50" cy="50" r="50" />';
					break;
				case 'triangle':
					$output .= '<polygon points="0 0, 100 0, 50 100" />';
					break;
				case 'big-triangle':
					$output .= '<polygon points="0 0, 50 100, 100 0, 0 0" />';
					break;
				case 'big-triangle-inv':
					$output .= '<polygon points="0 0, 50 90, 100 0, 100 100, 0 100" />';
					break;
			}
			$output .= '</svg>';
		}
		if ( $icon != '' ) {
			$output .= '<i class="' . mixt_element_sanitize_html_classes($icon) . '"></i>';
		}
	$output .= '</div>';

	return $output;
}
