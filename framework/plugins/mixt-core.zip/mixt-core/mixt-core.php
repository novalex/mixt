<?php

/**
 * Plugin Name: MIXT Core
 * Description: Highly versatile and customizable element shortcodes and portfolio
 * Version:     1.0
 * Author:      novalex
 * Author URI:  http://novalx.com
 * Text Domain: mixt-core
 * Domain Path: /lang/
 */

defined('ABSPATH') or die('You are not supposed to do that.'); // No Direct Access

// Set Constants

define( 'MIXTEL_VERSION', '1.0' );
define( 'MIXTEL_PLUGIN', __FILE__ );
define( 'MIXTEL_DIR', untrailingslashit( dirname(MIXTEL_PLUGIN) ) );
define( 'MIXTEL_INC_DIR', MIXTEL_DIR . '/inc' );
define( 'MIXTEL_ELEM_DIR', MIXTEL_DIR . '/elements' );
// Message to display for elements that require the MIXT theme
define( 'MIXTEL_DISABLED', '<p>' . esc_html__( 'This element requires the MIXT theme to be active!', 'mixt-core' ).'</p>' );

if ( defined('MIXT_IMG_PLACEHOLDER') ) {
	define( 'MIXTEL_IMG_PLACEHOLDER', MIXT_IMG_PLACEHOLDER );
} else {
	define( 'MIXTEL_IMG_PLACEHOLDER', 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=' );
}

if ( ! class_exists('Mixt_Elements') ) {

	class Mixt_Elements {

		public function __construct() {
			$this->setup();

			add_action('init', array($this, 'register_elements'), 5);
			add_action('plugins_loaded', array($this, 'load_textdomain'));
		}

		/**
		 * Load includes
		 */
		public function setup() {
			require_once(MIXTEL_INC_DIR . '/common.php');
			require_once(MIXTEL_INC_DIR . '/class-element.php');

			include_once(MIXTEL_INC_DIR . '/gallery.php');
			include_once(MIXTEL_INC_DIR . '/widget-shortcode.php');

			if ( defined('WPB_VC_VERSION') ) {
				include_once(MIXTEL_INC_DIR . '/vc-grid-items.php');
			}
		}

		/**
		 * Load plugin textdomain
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'mixt-core', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' ); 
		}

		/**
		 * Scan the elements directory and register them
		 */
		public function register_elements() {
			foreach ( glob( MIXTEL_ELEM_DIR . '/*.php' ) as $element ) {
				include $element;
			}
		}
	}
}
new Mixt_Elements;


if ( ! class_exists('Mixt_Portfolio') ) {

	class Mixt_Portfolio {

		/* @var array */
		public $options = array(
			'show-projects-author-archives' => false,
			'show-projects-date-archives'   => false,
		);

		/* @var array */
		public $permalinks = array();

		public function __construct() {
			add_action('init', array($this, 'get_options'), 4);
			add_action('init', array($this, 'register_post_types'), 5);
			add_action('init', array($this, 'register_taxonomies'), 5);

			add_filter('getarchives_where', array($this, 'getarchives_where_filter'), 10, 2);

			add_action('plugins_loaded', array($this, 'load_textdomain'));

			add_action('pre_get_posts', array($this, 'portfolio_archive'));
		}

		/**
		 * Perform plugin install actions upon activation
		 */
		public static function install() {
			add_action('wp_loaded', 'flush_rewrite_rules');
		}

		/**
		 * Get options
		 */
		public function get_options() {
			if ( function_exists('mixt_get_options') ) {
				$this->options = mixt_get_options( array(
					'show-projects-author-archives' => array(),
					'show-projects-date-archives' => array(),
				) );
			}
			$this->permalinks = apply_filters('mixt_portfolio_permalinks', array(
				'portfolio' => esc_html_x( 'portfolio', 'portfolio base permalink', 'mixt-core' ),
				'tax-type'  => esc_html_x( 'project-type', 'portfolio type taxonomy permalink', 'mixt-core' ),
				'tax-attr'  => esc_html_x( 'project-attribute', 'portfolio attribute taxonomy permalink', 'mixt-core' ),
			));
		}

		/**
		 * Load plugin textdomain
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'mixt-core', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' ); 
		}

		/**
		 * Include projects on author and date archive pages
		 */
		public function portfolio_archive( $query ) {
			$date_query   = ( $this->options['show-projects-date-archives'] && $query->is_date );
			$author_query = ( $this->options['show-projects-author-archives'] && $query->is_author );
			if ( $query->is_main_query() && ( $author_query || $date_query ) ) {
				$post_types = (array) $query->get('post_type');
				if ( empty($post_types[0]) ) { $post_types = array('post'); }
				$post_types[] = 'portfolio';
				$query->set('post_type', $post_types);
			}
		}

		/**
		 * Register custom post types
		 */
		public function register_post_types() {
			$portfolio_args = array(
				'labels'        => array(
					'name'          => esc_html__( 'Portfolio', 'mixt-core' ),
					'singular_name' => esc_html__( 'Project', 'mixt-core' ),
					'search_items'  => esc_html__( 'Search Projects', 'mixt-core' ),
					'all_items'     => esc_html__( 'Portfolio', 'mixt-core' ),
					'parent_item'   => esc_html__( 'Parent Project', 'mixt-core' ),
					'edit_item'     => esc_html__( 'Edit Project', 'mixt-core' ),
					'update_item'   => esc_html__( 'Update Project', 'mixt-core' ),
					'add_new_item'  => esc_html__( 'Add New Project', 'mixt-core' ),
				),
				'public'        => true,
				'show_ui'       => true,
				'menu_position' => '9.6498',
				'hierarchical'  => false,
				'query_var'     => true,
				'rewrite'       => array( 'slug' => $this->permalinks['portfolio'] ),
				'has_archive'   => true,
				'menu_icon'     => 'dashicons-portfolio',
				'supports'      => array( 'author', 'title', 'editor', 'excerpt', 'thumbnail', 'comments', 'revisions', 'custom-fields', 'post-formats' ),
				'show_in_menu'  => true,
				'show_in_nav_menus' => true,
			);
			register_post_type('portfolio' , $portfolio_args);
		}

		/**
		 * Register custom taxonomies
		 */
		public function register_taxonomies() {
			// Project Types
			register_taxonomy(
				'project-type',
				'portfolio',
				array(
					'labels'       => array(
						'name'          => esc_html__( 'Project Types', 'mixt-core' ),
						'singular_name' => esc_html__( 'Project Type', 'mixt-core' ),
						'search_items'  => esc_html__( 'Search Project Types', 'mixt-core' ),
						'all_items'     => esc_html__( 'All Project Types', 'mixt-core' ),
						'parent_item'   => esc_html__( 'Parent Project Type', 'mixt-core' ),
						'edit_item'     => esc_html__( 'Edit Project Type', 'mixt-core' ),
						'update_item'   => esc_html__( 'Update Project Type', 'mixt-core' ),
						'add_new_item'  => esc_html__( 'Add New Project Type', 'mixt-core' ),
						'new_item_name' => esc_html__( 'New Project Type', 'mixt-core' ),
						'menu_name'     => esc_html__( 'Project Types', 'mixt-core' ),
					),
					'show_ui'      => true,
					'hierarchical' => true,
					'query_var'    => true,
					'rewrite'      => array( 'slug' => $this->permalinks['tax-type'], 'with_front' => false ),
				)
			);

			// Project Attributes
			register_taxonomy(
				'project-attribute',
				'portfolio',
				array(
					'labels'       => array(
						'name'          => esc_html__( 'Project Attributes', 'mixt-core' ),
						'singular_name' => esc_html__( 'Project Attribute', 'mixt-core' ),
						'search_items'  => esc_html__( 'Search Project Attributes', 'mixt-core' ),
						'all_items'     => esc_html__( 'All Project Attributes', 'mixt-core' ),
						'parent_item'   => esc_html__( 'Parent Project Attribute', 'mixt-core' ),
						'edit_item'     => esc_html__( 'Edit Project Attribute', 'mixt-core' ),
						'update_item'   => esc_html__( 'Update Project Attribute', 'mixt-core' ),
						'add_new_item'  => esc_html__( 'Add New Project Attribute', 'mixt-core' ),
						'new_item_name' => esc_html__( 'New Project Attribute', 'mixt-core' ),
						'menu_name'     => esc_html__( 'Project Attributes', 'mixt-core' ),
					),
					'show_ui'      => true,
					'hierarchical' => true,
					'query_var'    => true,
					'rewrite'      => array( 'slug' => $this->permalinks['tax-attr'], 'with_front' => false ),
				)
			);

			// Project Formats
			register_taxonomy_for_object_type('post_format', 'portfolio');
		}

		/**
		 * Modify the query to show only portfolio type posts
		 */
		function getarchives_where_filter( $where, $args ) {
			if ( isset($args['post_type']) && $args['post_type'] == 'portfolio' ) {      
				$where = "WHERE post_type = 'portfolio' AND post_status = 'publish'";
			}
			return $where;
		}
	}
}
new Mixt_Portfolio();

register_activation_hook(__FILE__, array('Mixt_Portfolio', 'install'));

register_deactivation_hook(__FILE__, 'flush_rewrite_rules');


if ( ! function_exists('mixt_portfolio_filters') ) {
	/**
	 * Output portfolio filtering links
	 */
	function mixt_portfolio_filters() {
		$terms = get_terms('project-type');

		if ( empty($terms) ) { return; }

		$output = '<ul class="portfolio-sorter link-list">';
			$output .= '<li class="active"><a href="#" data-sort="all">' . esc_html_x( 'All', 'portfolio filter', 'mixt-core' ) . '</a></li>';
			foreach ( $terms as $term ) {
				$name = $term->name;
				$sort = $term->taxonomy . '-' . $term->slug;

				$output .= '<li><a href="#" data-sort="' . esc_attr($sort) . '">' . esc_html($name) . '</a></li>';
			}
		$output .= '</ul>';

		echo $output;
	}
}
