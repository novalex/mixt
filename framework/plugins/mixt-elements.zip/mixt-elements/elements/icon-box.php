<?php

/**
 * Icon Box Element
 */
class Mixt_Iconbox extends Mixt_Element {

	/**
	 * @var array $colors
	 * @var array $icon_sizes
	 * @var array $icon_styles
	 * @var array $icon_colors
	 * @var array $icon_positions
	 * @var array $image_styles
	 */
	public $colors, $icon_sizes, $icon_styles, $icon_colors, $icon_positions, $image_styles;
	
	public function __construct() {
		parent::__construct();

		$this->colors = mixt_element_assets('colors', 'basic');
		$this->icon_styles = array_merge(
			mixt_element_assets('icon-styles'),
			array( 'background' => esc_html__( 'Background', 'mixt-elements' ) )
		);
		$this->icon_sizes = mixt_element_assets('icon-sizes');
		$this->icon_colors = array_merge(
			array( 'auto' => esc_html__( 'Auto', 'mixt-elements' ) ),
			$this->colors
		);
		$this->icon_positions = array(
			'top'         => esc_html__( 'Top', 'mixt-elements' ),
			'left'        => esc_html__( 'Left', 'mixt-elements' ),
			'title-left'  => esc_html__( 'Left of title', 'mixt-elements' ),
			'right'       => esc_html__( 'Right', 'mixt-elements' ),
			'title-right' => esc_html__( 'Right of title', 'mixt-elements' ),
			'bottom'      => esc_html__( 'Bottom', 'mixt-elements' ),
		);
		$this->image_styles = mixt_element_assets('image-styles');

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_iconbox', array($this, 'shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_iconbox',
			'title'    => esc_html__( 'Icon Box', 'mixt-elements' ),
			'template' => '[mixt_iconbox {{attributes}}]{{content}}[/mixt_iconbox]',
			'params'   => array(
				'style' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Box Style', 'mixt-elements' ),
					'options' => array(
						'plain'    => esc_html__( 'Plain', 'mixt-elements' ),
						'bordered' => esc_html__( 'Bordered', 'mixt-elements' ),
						'solid'    => esc_html__( 'Solid', 'mixt-elements' ),
					),
					'std' => 'plain',
				),
				'box_color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Box Color', 'mixt-elements' ),
					'options'  => $this->colors,
					'required' => array('style', '=', 'solid'),
					'class'    => 'color-select basic-colors',
					'std'      => 'white',
				),
				'border_color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Border Color', 'mixt-elements' ),
					'options'  => array_merge(
						array( 'auto' => esc_html__( 'Auto', 'mixt-elements' ) ),
						$this->colors
					),
					'required' => array('style', '=', 'bordered'),
					'class'    => 'color-select basic-colors',
					'std'      => 'auto',
				),
				'title' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Title', 'mixt-elements' ),
				),
				'icon_type' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Type', 'mixt-elements' ),
					'options' => array(
						'icon'  => esc_html__( 'Font Icon', 'mixt-elements' ),
						'image' => esc_html__( 'Image', 'mixt-elements' ),
					),
					'std'     => 'icon',
				),
				'icon' => array(
					'type'     => 'text',
					'label'    => esc_html__( 'Icon', 'mixt-elements' ),
					'std'      => 'fa fa-check',
					'required' => array('icon_type', '=', 'icon'),
				),
				'icon_style' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Icon Style', 'mixt-elements' ),
					'options'  => $this->icon_styles,
					'required' => array('icon_type', '=', 'icon'),
				),
				'icon_color' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Icon Color', 'mixt-elements' ),
					'options'  => $this->icon_colors,
					'class'    => 'color-select basic-colors',
					'std'      => 'auto',
					'required' => array('icon_type', '=', 'icon'),
				),
				'image' => array(
					'type'     => 'media',
					'label'    => esc_html__( 'Icon', 'mixt-elements' ),
					'required' => array('icon_type', '=', 'image'),
				),
				'image_style' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Icon Style', 'mixt-elements' ),
					'options'  => $this->image_styles,
					'required' => array('icon_type', '=', 'image'),
				),
				'icon_bg' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Background / Border Color', 'mixt-elements' ),
					'options' => $this->colors,
					'class'   => 'color-select basic-colors',
					'std'     => '',
				),
				'icon_size' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Size', 'mixt-elements' ),
					'options' => $this->icon_sizes,
					'std'     => '',
				),
				'icon_pos' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Position', 'mixt-elements' ),
					'options' => $this->icon_positions,
					'std'     => 'top',
				),
				'icon_valign' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Icon Alignment', 'mixt-elements' ),
					'options'  => array(
						'top'    => esc_html__( 'Top', 'mixt-elements' ),
						'middle' => esc_html__( 'Middle', 'mixt-elements' ),
						'bottom' => esc_html__( 'Bottom', 'mixt-elements' ),
					),
					'required' => array('icon_pos', '=', 'left|right'),
					'std'      => 'middle',
				),
				'icon_halign' => array(
					'type'     => 'select',
					'label'    => esc_html__( 'Icon Alignment', 'mixt-elements' ),
					'options'  => array(
						'left'   => esc_html__( 'Left', 'mixt-elements' ),
						'center' => esc_html__( 'Center', 'mixt-elements' ),
						'right'  => esc_html__( 'Right', 'mixt-elements' ),
					),
					'required' => array('icon_pos', '=', 'top|bottom'),
					'std'      => 'center',
				),
				'icon_anim' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Icon Animation', 'mixt-elements' ),
					'options' => $this->icon_anims,
				),
				'icon_out' => array(
					'type'     => 'checkbox',
					'label'    => esc_html__( 'Icon Outside', 'mixt-elements' ),
					'desc'     => esc_html__( 'Position icon outside of the box', 'mixt-elements' ),
					'required' => array('icon_pos', '=', 'top|left|right|bottom'),
				),
				'content' => array(
					'type'   => 'encoded_textarea',
					'label'  => esc_html__( 'Content', 'mixt-elements' ),
					'desc'   => esc_html__( 'The box\'s content', 'mixt-elements' ),
					'std'    => 'Icon box content',
				),
				'animation' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Animation', 'mixt-elements' ),
					'options' => $this->animations,
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-elements' ),
				),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		vc_map( array(
			'name'        => esc_html__( 'Icon Box', 'mixt-elements' ),
			'description' => esc_html__( 'A box with an icon!', 'mixt-elements' ),
			'base'        => 'mixt_iconbox',
			'icon'        => 'mixt_iconbox',
			'category'    => 'MIXT',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Box Style', 'mixt-elements' ),
					'param_name'  => 'style',
					'value'       => array(
						esc_html__( 'Plain', 'mixt-elements' ) => 'plain',
						esc_html__( 'Bordered', 'mixt-elements' ) => 'bordered',
						esc_html__( 'Solid', 'mixt-elements' ) => 'solid',
					),
					'std' => 'plain',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Box Color', 'mixt-elements' ),
					'param_name'  => 'box_color',
					'value'       => array_flip($this->colors),
					'std'         => 'white',
					'dependency'  => array( 'element' => 'style', 'value' => 'solid' ),
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Border Color', 'mixt-elements' ),
					'param_name'  => 'border_color',
					'value'       => array_flip( array_merge(
						array( 'auto' => esc_html__( 'Auto', 'mixt-elements' ) ),
						$this->colors
					) ),
					'std'         => 'auto',
					'dependency'  => array( 'element' => 'style', 'value' => 'bordered' ),
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Title', 'mixt-elements' ),
					'param_name'  => 'title',
					'admin_label' => true,
					'std'         => '',
				),
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Content', 'mixt-elements' ),
					'description' => esc_html__( 'The box\'s content', 'mixt-elements' ),
					'param_name'  => 'content',
					'admin_label' => true,
					'std'         => 'Icon box content',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Animation', 'mixt-elements' ),
					'param_name' => 'animation',
					'value'      => array_flip($this->animations),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra Classes', 'mixt-elements' ),
					'param_name'  => 'class',
				),

				// Icon Tab
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Type', 'mixt-elements' ),
					'value'       => array(
						esc_html__( 'Image', 'mixt-elements' ) => 'image',
						'Font Awesome' => 'fontawesome',
						'Typicons'     => 'typicons',
						'Entypo'       => 'entypo',
						'Linecons'     => 'linecons',
					),
					'param_name'  => 'icon_type',
					'std'         => 'fontawesome',
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-elements' ),
					'param_name'  => 'icon_fontawesome',
					'value'       => 'fa fa-check',
					'settings'    => array( 'emptyIcon' => false ),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'fontawesome' ),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-elements' ),
					'param_name'  => 'icon_typicons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'typicons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'typicons' ),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-elements' ),
					'param_name'  => 'icon_entypo',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'entypo',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'entypo' ),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'iconpicker',
					'heading'     => esc_html__( 'Icon', 'mixt-elements' ),
					'param_name'  => 'icon_linecons',
					'settings'    => array(
						'emptyIcon' => false,
						'type'      => 'linecons',
					),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'linecons' ),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Style', 'mixt-elements' ),
					'param_name' => 'icon_style',
					'value'      => array_flip($this->icon_styles),
					'std'        => 'default',
					'dependency' => array(
						'element' => 'icon_type',
						'value'   => array('fontawesome', 'typicon', 'entypo', 'linecons'),
					),
					'group'      => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Color', 'mixt-elements' ),
					'param_name'  => 'icon_color',
					'value'       => array_flip($this->icon_colors),
					'std'         => 'auto',
					'param_holder_class' => 'color-select basic-colors',
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => array('fontawesome', 'typicon', 'entypo', 'linecons'),
					),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'attach_image',
					'heading'     => esc_html__( 'Icon', 'mixt-elements' ),
					'param_name'  => 'image',
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'image' ),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Style', 'mixt-elements' ),
					'param_name'  => 'image_style',
					'value'       => array_flip($this->image_styles),
					'dependency'  => array( 'element' => 'icon_type', 'value' => 'image' ),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Background / Border Color', 'mixt-elements' ),
					'param_name'  => 'icon_bg',
					'value'       => array_flip($this->colors),
					'std'         => '',
					'param_holder_class' => 'color-select basic-colors',
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon Size', 'mixt-elements' ),
					'param_name'  => 'icon_size',
					'value'       => array_flip($this->icon_sizes),
					'std'         => '',
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Position', 'mixt-elements' ),
					'param_name' => 'icon_pos',
					'value'      => array_flip($this->icon_positions),
					'std'        => 'top',
					'group'      => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Alignment', 'mixt-elements' ),
					'param_name' => 'icon_valign',
					'value'      => array(
						esc_html__( 'Top', 'mixt-elements' )    => 'top',
						esc_html__( 'Middle', 'mixt-elements' ) => 'middle',
						esc_html__( 'Bottom', 'mixt-elements' ) => 'bottom',
					),
					'dependency' => array(
						'element' => 'icon_pos',
						'value'   => array('left', 'right'),
					),
					'std'        => 'middle',
					'group'      => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Alignment', 'mixt-elements' ),
					'param_name' => 'icon_halign',
					'value'      => array(
						esc_html__( 'Left', 'mixt-elements' )   => 'left',
						esc_html__( 'Center', 'mixt-elements' ) => 'center',
						esc_html__( 'Right', 'mixt-elements' )  => 'right',
					),
					'dependency' => array(
						'element' => 'icon_pos',
						'value'   => array('top', 'bottom'),
					),
					'std'        => 'center',
					'group'      => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Icon Animation', 'mixt-elements' ),
					'param_name' => 'icon_anim',
					'value'      => array_flip($this->icon_anims),
					'group'      => esc_html__( 'Icon', 'mixt-elements' ),
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Icon Outside', 'mixt-elements' ),
					'description' => esc_html__( 'Position icon outside of the box', 'mixt-elements' ),
					'param_name'  => 'icon_out',
					'dependency'  => array(
						'element' => 'icon_pos',
						'value'   => array('top', 'left', 'right', 'bottom'),
					),
					'group'       => esc_html__( 'Icon', 'mixt-elements' ),
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'bg' => array(
							'selector' => '.inner',
							'label'    => esc_html__( 'Background Color', 'mixt-elements' ),
							'pattern'  => 'background-color: {{val}}',
							'group'    => esc_html__( 'Box', 'mixt-elements' ),
						),
						'color' => array(
							'selector' => '.inner',
							'label'    => esc_html__( 'Text Color', 'mixt-elements' ),
							'pattern'  => 'color: {{val}}',
							'group'    => esc_html__( 'Box', 'mixt-elements' ),
						),
						'border' => array(
							'selector' => '.inner',
							'label'    => esc_html__( 'Border Color', 'mixt-elements' ),
							'pattern'  => 'border-color: {{val}}',
							'group'    => esc_html__( 'Box', 'mixt-elements' ),
						),
						'custom' => array(
							'type'     => 'custom',
							'selector' => '.inner',
							'label'    => esc_html__( 'Custom CSS', 'mixt-elements' ),
						),
					),
					'group'      => 'Styler',
				),

				// Design Tab
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS', 'mixt-elements' ),
					'group'      => esc_html__( 'Design Options', 'mixt-elements' ),
					'param_name' => 'css',
				),
			),
		) );
	}

	/**
	 * Render shortcode
	 */
	public function shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'style'        => 'plain',
			'border_color' => 'auto',
			'box_color'    => 'white',
			'title'        => '',
			'animation'    => '',
			'class'        => '',

			'styler'       => '',

			'css'          => '',

			'icon'         => '',
			'icon_style'   => 'default',
			'image'        => '',
			'image_style'  => '',
			'icon_color'   => 'auto',
			'icon_bg'      => '',
			'icon_size'    => '',
			'icon_pos'     => 'top',
			'icon_valign'  => 'middle',
			'icon_halign'  => 'center',
			'icon_anim'    => '',
			'icon_out'     => false,
			'icon_type'        => 'fontawesome',
			'icon_fontawesome' => 'fa fa-check',
			'icon_typicons'    => '',
			'icon_entypo'      => '',
			'icon_linecons'    => '',
		), $atts );

		// VC custom design options
		if ( ! empty($args['css']) && defined( 'WPB_VC_VERSION' ) ) {
			$args['class'] .= apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $args['css'], ' ' ), 'mixt_iconbox', $atts );
		}

		// Styler custom design
		if ( $args['styler'] != '' ) {
			$args['class'] .= mixt_element_styler($args['styler']);
		}

		$args['icon'] = mixt_element_icon_class($args);

		extract($args);

		// Box Classes
		$classes = 'mixt-iconbox mixt-element icon-cont';
		if ( $icon_style != 'background' ) {
			$classes .=  ' icon-' . $icon_pos;
			if ( $icon_size != '' ) $classes .= ' ' . $icon_size;
			if ( $icon_out ) $classes .= ' icon-outside';
		}
		if ( ! empty($animation) ) $classes .= ' ' . $this->element_animate($animation);
		if ( $class != '' ) $classes .= ' ' . $class;
		$classes = mixt_element_sanitize_html_classes($classes);

		// Inner Classes
		$inner_classes = 'inner ' . $style;
		if ( $style == 'bordered' ) {
			if ( $border_color == 'auto' ) $border_color = 'theme-bd';
			$inner_classes .= ' ' . $border_color;
		} else if ( $style == 'solid' ) {
			$inner_classes .= ' ' . $box_color;
		}
		if ( $icon_pos == 'left' || $icon_pos == 'right' ) {
			$inner_classes .= ' valign-' . $icon_valign;
		} else if ( $icon_pos == 'top' || $icon_pos == 'bottom' ) {
			$inner_classes .= ' halign-' . $icon_halign;
		}
		$inner_classes = mixt_element_sanitize_html_classes($inner_classes);

		// Icon
		if ( $icon_type == 'image' ) {
			$img_classes = 'icon mixt-image';
			$img_wrap_classes = 'image-wrap ' . $image_style;
			if ( $icon_bg != '' ) { $img_wrap_classes .= ' ' . $icon_bg; }
			$img_wrap_classes = mixt_element_sanitize_html_classes($img_wrap_classes);
			$icon_html = "<div class='$img_classes'><div class='$img_wrap_classes'>" . wp_get_attachment_image($image, 'full') . "</div></div>";
		} else {
			$icon_classes = 'icon mixt-icon';
			if ( $icon_style == 'background' ) {
				$classes .= ' icon-background';
			} else {
				$icon_classes .= ' ' . $icon_style;
				if ( $icon_size != '' ) $icon_classes .= ' ' . $icon_size;
				if ( $icon_style != 'default' ) {
					if ( $icon_bg != '' ) { $icon_classes .= ' ' . $icon_bg; }
					if ( $icon_anim != '' ) { $icon_classes .= " anim $icon_anim"; }
				}
			}
			$icon_classes = mixt_element_sanitize_html_classes($icon_classes);
			$icon_color = sanitize_html_class($icon_color);
			$icon_html = "<span class='$icon_classes'><i class='$icon $icon_color'></i></span>";
		}

		$icon_html = '<div class="icon-wrap">' . $icon_html . '</div>';

		ob_start();
		?>

		<div class="<?php echo $classes; ?>">
			<div class="<?php echo $inner_classes; ?>">
				<?php if ( $icon_pos == 'top' || $icon_pos == 'left' ) { echo $icon_html; } ?>
				<div class="content"><?php
					if ( $title != '' ) { ?>
						<div class="title-wrap">
							<?php if ( $icon_pos == 'title-left' ) { echo $icon_html; } ?>
							<strong class="title"><?php echo esc_html($title); ?></strong>
							<?php if ( $icon_pos == 'title-right' ) { echo $icon_html; } ?>
						</div>
					<?php }
					echo apply_filters('mixt_unautop', html_entity_decode($content)); ?>
				</div>
				<?php if ( $icon_pos == 'right' || $icon_pos == 'bottom' ) { echo $icon_html; } ?>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}
}
new Mixt_Iconbox;

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_IconBox extends WPBakeryShortCode {}
}
