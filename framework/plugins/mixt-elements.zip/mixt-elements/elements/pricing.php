<?php

/**
 * Pricing Tables
 */
class Mixt_Pricing {

	/** @var array */
	public $colors;

	public function __construct() {
		$this->colors = array_merge( array(
			'' => esc_html__( 'Default', 'mixt-elements' ) ),
			mixt_element_assets('colors', 'basic')
		);

		add_action('mixtcb_init', array($this, 'mixtcb_extend'));
		add_action('vc_before_init', array($this, 'vc_extend'));
		add_shortcode('mixt_pricing', array($this, 'table_shortcode'));
		add_shortcode('mixt_pricing_row', array($this, 'row_shortcode'));
	}

	/**
	 * Add Element to CodeBuilder
	 */
	public function mixtcb_extend() {
		mixtcb_map( array(
			'id'       => 'mixt_pricing',
			'title'    => esc_html__( 'Pricing Table', 'mixt-elements' ),
			'template' => '[mixt_pricing {{attributes}}]{{nested}}[/mixt_pricing]',
			'params'   => array(
				'plan_name' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Plan Name', 'mixt-elements' ),
					'std'   => 'Standard Plan',
				),
				'plan_desc' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Plan Description', 'mixt-elements' ),
					'std'   => 'Our standard plan, for individual needs',
				),
				'price' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Price', 'mixt-elements' ),
					'desc'  => esc_html__( 'Enter the price and currency for this plan. The currency symbol position will be kept.', 'mixt-elements' ),
					'std'   => '$25.99',
				),
				'plan_time' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Plan Duration', 'mixt-elements' ),
				),
				'highlight' => array(
					'type'  => 'checkbox',
					'label' => esc_html__( 'Highlighted', 'mixt-elements' ),
					'desc'  => esc_html__( 'Check to make this plan stand out from the rest', 'mixt-elements' ),
				),
				'scheme' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Color Scheme', 'mixt-elements' ),
					'desc'    => esc_html__( 'Light or dark color scheme', 'mixt-elements' ),
					'options' => array(
						'light' => esc_html__( 'Light', 'mixt-elements' ),
						'dark'  => esc_html__( 'Dark', 'mixt-elements' ),
					),
				),
				'color' => array(
					'type'    => 'select',
					'label'   => esc_html__( 'Header Color', 'mixt-elements' ),
					'options' => $this->colors,
					'class'   => 'color-select basic-colors',
				),
				'button' => array(
					'type'  => 'button',
					'label' => esc_html__( 'Button Style', 'mixt-elements' ),
				),
				'btn_text' => array(
					'type'    => 'text',
					'label'   => esc_html__( 'Button Text', 'mixt-elements' ),
					'desc'    => esc_html__( 'Text for the CTA button', 'mixt-elements' ),
					'std'     => 'Buy Now',
				),
				'btn_link' => array(
					'type'    => 'text',
					'label'   => esc_html__( 'Button Link', 'mixt-elements' ),
					'desc'    => esc_html__( 'CTA button link (href)', 'mixt-elements' ),
					'std'     => 'http://example.com',
				),
				'class' => array(
					'type'  => 'text',
					'label' => esc_html__( 'Extra Classes', 'mixt-elements' ),
				),
			),
			'nested' => array(
				'template' => '[mixt_pricing_row]{{content}}[/mixt_pricing_row]',
				'params' => array(
					'content' => array(
						'type'  => 'encoded_textarea',
						'label' => esc_html__( 'Text', 'mixt-elements' ),
						'desc'  => esc_html__( 'Table row text, can contain HTML', 'mixt-elements' ),
					),
					'class' => array(
						'type'  => 'text',
						'label' => esc_html__( 'Extra Classes', 'mixt-elements' ),
					),
				),
				'child_title'  => esc_html__( 'Table Row', 'mixt-elements' ),
				'clone_button' => esc_html__( 'Add Row', 'mixt-elements' ),
			),
		) );
	}

	/**
	 * Add Element to Visual Composer
	 */
	public function vc_extend() {
		// Table
		vc_map( array(
			'name'        => esc_html__( 'Pricing Table', 'mixt-elements' ),
			'description' => esc_html__( 'Feature & pricing table', 'mixt-elements' ),
			'base'        => 'mixt_pricing',
			'icon'        => 'mixt_pricing',
			'category'    => 'MIXT',
			'as_parent'   => array('only' => 'mixt_pricing_row'),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Plan Name', 'mixt-elements' ),
					'param_name'  => 'plan_name',
					'admin_label' => true,
					'std'         => 'Standard Plan',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Plan Description', 'mixt-elements' ),
					'param_name' => 'plan_desc',
					'std'        => 'Our standard plan, for individual needs',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Price', 'mixt-elements' ),
					'description' => esc_html__( 'Enter the price and currency for this plan. The currency symbol position will be kept.', 'mixt-elements' ),
					'param_name'  => 'price',
					'admin_label' => true,
					'std'         => '$25.99',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Plan Duration', 'mixt-elements' ),
					'param_name'  => 'plan_time',
				),
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Highlighted', 'mixt-elements' ),
					'description' => esc_html__( 'Check to make this plan stand out from the rest', 'mixt-elements' ),
					'param_name'  => 'highlight',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Color Scheme', 'mixt-elements' ),
					'description' => esc_html__( 'Light or dark color scheme', 'mixt-elements' ),
					'value'       => array(
						esc_html__( 'Light', 'mixt-elements' ) => 'light',
						esc_html__( 'Dark', 'mixt-elements' )  => 'dark',
					),
					'param_name'  => 'scheme',
				),
				array(
					'type'       => 'dropdown',
					'heading'    => esc_html__( 'Header Color', 'mixt-elements' ),
					'value'      => array_flip($this->colors),
					'param_name' => 'color',
					'param_holder_class' => 'color-select basic-colors',
				),
				array(
					'type'       => 'button',
					'heading'    => esc_html__( 'Button Style', 'mixt-elements' ),
					'param_name' => 'button',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Button Text', 'mixt-elements' ),
					'description' => esc_html__( 'Text for the CTA button', 'mixt-elements' ),
					'param_name'  => 'btn_text',
					'std'         => 'Buy Now',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Button Link', 'mixt-elements' ),
					'description' => esc_html__( 'CTA button link (href)', 'mixt-elements' ),
					'param_name'  => 'btn_link',
					'std'         => 'http://example.com',
				),

				// Styler
				array(
					'type'       => 'styler',
					'param_name' => 'styler',
					'fields'     => array(
						'bg' => array(
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Background Color', 'mixt-elements' ),
							'pattern'  => 'background-color: {{val}}',
						),
						'color' => array(
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Text Color', 'mixt-elements' ),
							'pattern'  => 'color: {{val}}',
						),
						'border' => array(
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Border Color', 'mixt-elements' ),
							'pattern'  => 'border-color: {{val}}',
						),

						'header-bg' => array(
							'selector' => '.header',
							'label'    => esc_html__( 'Background Color', 'mixt-elements' ),
							'pattern'  => 'background-color: {{val}}',
							'group'    => esc_html__( 'Header', 'mixt-elements' ),
						),
						'header-color' => array(
							'selector' => '.header',
							'label'    => esc_html__( 'Text Color', 'mixt-elements' ),
							'pattern'  => 'color: {{val}}',
							'group'    => esc_html__( 'Header', 'mixt-elements' ),
						),
						'header-border' => array(
							'selector' => '.header',
							'label'    => esc_html__( 'Border Color', 'mixt-elements' ),
							'pattern'  => 'border-color: {{val}}',
							'group'    => esc_html__( 'Header', 'mixt-elements' ),
						),
						'custom' => array(
							'type'     => 'custom',
							'selector' => '.mixt-pricing-inner',
							'label'    => esc_html__( 'Custom CSS', 'mixt-elements' ),
						),
					),
					'group'      => 'Styler',
				),

				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-elements' ),
					'param_name' => 'class',
				),
			),
		) );

		// Feature / row
		vc_map( array(
			'name'        => esc_html__( 'Row', 'mixt-elements' ),
			'base'        => 'mixt_pricing_row',
			'icon'        => 'mixt_pricing',
			'category'    => 'MIXT',
			'as_child'    => array('only' => 'mixt_pricing'),
			'params'      => array(
				array(
					'type'        => 'textarea_html',
					'heading'     => esc_html__( 'Text', 'mixt-elements' ),
					'description' => esc_html__( 'Table row text, can contain HTML', 'mixt-elements' ),
					'param_name'  => 'content',
					'admin_label' => true,
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Extra Classes', 'mixt-elements' ),
					'param_name' => 'class',
				),
			),
		) );
	}

	/**
	 * Render table shortcode
	 */
	public function table_shortcode( $atts, $content = null ) {
		$args = shortcode_atts( array(
			'plan_name' => 'Standard Plan',
			'plan_desc' => 'Our standard plan, for individual needs',
			'price'     => '$25.99',
			'plan_time' => '',
			'highlight' => false,
			'scheme'    => '',
			'color'     => '',
			'btn_text'  => 'Buy Now',
			'btn_link'  => 'http://example.com',
			'button'    => '',
			'styler'    => '',
			'class'     => '',
		), $atts );

		// Styler custom design
		if ( $args['styler'] != '' ) {
			$args['class'] .= mixt_element_styler($args['styler']);
		}

		extract($args);

		$classes = 'pricing-table mixt-pricing mixt-element';
		if ( $highlight ) $classes .= ' highlight';
		if ( $scheme == 'dark' ) $classes .= ' dark';
		if ( $color != '' ) $classes .= ' ' . sanitize_html_class($color);
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);

		if ( $price != '' ) {
			preg_match('/^(\D*)\s*([\d,\.]+)\s*(\D*)$/', $price, $price_arr);
			if ( empty($price_arr[1]) ) {
				$currency = $price_arr[3];
				$currency_position = 'after';
			} else {
				$currency = $price_arr[1];
				$currency_position = 'before';
			}
			$price_amount = explode('.', $price_arr[2]);
		} else {
			$currency_position = null;
			$price_amount = array('', '');
		}

		ob_start();
		?>
		<div class="<?php echo $classes; ?>">
			<ul class="pricing-table-inner mixt-pricing-inner">
				<li class="header">
					<h3 class="plan-name"><?php echo esc_html($plan_name); ?></h3>
					<?php if ( ! empty($plan_desc) ) echo '<p class="plan-desc">' . esc_html($plan_desc) . '</p>'; ?>
					<strong class="price"><?php
						if ( $currency_position == 'before' ) echo "<small class='symbol'>$currency</small>";
						echo $price_amount[0];
						if ( ! empty($price_amount[1]) ) echo "<small class='price-decimal'>{$price_amount[1]}</small>";
						if ( $currency_position == 'after' ) echo "<small class='symbol'>$currency</small>";
						if ( ! empty($plan_time) ) echo "<small class='plan-time'>$plan_time</small>";
					?></strong>
				</li>
				<?php

				// Table Rows
				echo do_shortcode($content);
				?>
				<li class="footer">
					<a href="<?php echo esc_url($btn_link); ?>" class="<?php echo mixt_element_button($button); ?>"><?php echo esc_html($btn_text); ?></a>
				</li>
			</ul>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render table row shortcode
	 */
	public function row_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'class' => '',
		), $atts ) );
		$classes = '';
		if ( empty($content) ) return;
		if ( $class != '' ) $classes .= ' ' . mixt_element_sanitize_html_classes($class);
		$content = apply_filters('mixt_unautop', html_entity_decode($content));

		return "<li class='$classes'>$content</li>";
	}
}
new Mixt_Pricing;

if ( class_exists('WPBakeryShortCodesContainer') ) {
	class WPBakeryShortCode_Mixt_Pricing extends WPBakeryShortCodesContainer {}
}

if ( class_exists('WPBakeryShortCode') ) {
	class WPBakeryShortCode_Mixt_Pricing_Row extends WPBakeryShortCode {}
}
