<?php

/**
 * Custom Gallery
 *
 * @package MIXT
 */

defined('ABSPATH') or die('You are not supposed to do that.'); // No Direct Access

/**
 * Custom Gallery Shortcode
 *
 * @param array $attr Attributes of the shortcode.
 *
 * @return string HTML content to display gallery.
 */
function mixt_gallery_shortcode($attr) {
	$post = get_post();

	static $instance = 0;
	$instance++;

	if ( ! empty( $attr['ids'] ) ) {
		// 'ids' is explicitly ordered, unless you specify otherwise.
		if ( empty( $attr['orderby'] ) ) {
			$attr['orderby'] = 'post__in';
		}
		$attr['include'] = $attr['ids'];
	}

	/**
	 * Filter the default gallery shortcode output.
	 *
	 * If the filtered output isn't empty, it will be used instead of generating
	 * the default gallery template.
	 *
	 * @since 2.5.0
	 * @since 4.2.0 The `$instance` parameter was added.
	 *
	 * @see gallery_shortcode()
	 *
	 * @param string $output   The gallery output. Default empty.
	 * @param array  $attr     Attributes of the gallery shortcode.
	 * @param int    $instance Unique numeric ID of this gallery shortcode instance.
	 */
	$output = apply_filters( 'post_gallery', '', $attr, $instance );
	if ( $output != '' ) {
		return $output;
	}

	$html5 = current_theme_supports( 'html5', 'gallery' );
	$atts = shortcode_atts( array(
		'order'      => 'ASC',
		'orderby'    => 'menu_order ID',
		'id'         => $post ? $post->ID : 0,
		'itemtag'    => $html5 ? 'figure'     : 'dl',
		'icontag'    => $html5 ? 'div'        : 'dt',
		'captiontag' => $html5 ? 'figcaption' : 'dd',
		'columns'    => 3,
		'size'       => 'thumbnail',
		'include'    => '',
		'exclude'    => '',
		'link'       => '',
		// MIXT MOD
		'conttag'    => 'div',
		'type'       => 'standard',
		'feat'       => false,
		// END MIXT MOD
	), $attr, 'gallery' );

	$id = intval( $atts['id'] );

	if ( ! empty( $atts['include'] ) ) {
		$_attachments = get_posts( array( 'include' => $atts['include'], 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );

		$attachments = array();
		foreach ( $_attachments as $key => $val ) {
			$attachments[$val->ID] = $_attachments[$key];
		}
	} elseif ( ! empty( $atts['exclude'] ) ) {
		$attachments = get_children( array( 'post_parent' => $id, 'exclude' => $atts['exclude'], 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
	} else {
		$attachments = get_children( array( 'post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
	}

	if ( empty($attachments) ) {
		return '';
	}

	if ( is_feed() ) {
		$output = "\n";
		foreach ( $attachments as $att_id => $attachment ) {
			$output .= wp_get_attachment_link( $att_id, $atts['size'], true ) . "\n";
		}
		return $output;
	}

	$itemtag = tag_escape( $atts['itemtag'] );
	$captiontag = tag_escape( $atts['captiontag'] );
	$icontag = tag_escape( $atts['icontag'] );
	$valid_tags = wp_kses_allowed_html( 'post' );
	if ( ! isset( $valid_tags[ $itemtag ] ) ) {
		$itemtag = 'dl';
	}
	if ( ! isset( $valid_tags[ $captiontag ] ) ) {
		$captiontag = 'dd';
	}
	if ( ! isset( $valid_tags[ $icontag ] ) ) {
		$icontag = 'dt';
	}

	$columns = intval( $atts['columns'] );
	$itemwidth = $columns > 0 ? floor(100/$columns) : 100;
	$float = is_rtl() ? 'right' : 'left';

	$selector = "gallery-{$instance}";

	$gallery_style = '';

	$size_class = sanitize_html_class($atts['size']);

	// MIXT MOD
	$conttag = $atts['conttag'];

	if ( $atts['type'] == 'slider' || $atts['type'] == 'lightbox' ) {
		$output = $br_tag = '';
		$conttag = 'ul';
		$itemtag = 'li';
		$icontag = 'div';
		$captiontag = 'p';
	}

	if ( $atts['type'] == 'slider' ) {
		$gallery_classes = 'gallery-slider';

		// Enqueue the lightslider script
		mixt_element_enqueue_plugin('lightslider');
	} else if ( $atts['type'] == 'lightbox' ) {
		$gallery_classes = 'lightbox-gallery';

		// Enqueue the lightGallery plugin
		mixt_element_enqueue_plugin('lightgallery');
	} else {
		$gallery_classes = 'standard-gallery';
	}

	if ( $atts['feat'] ) { $gallery_classes .= ' featured'; }

	$gallery_div = "<{$conttag} id='$selector' class='gallery galleryid-{$id} gallery-columns-{$columns} gallery-size-{$size_class} $gallery_classes'>";

	/**
	 * Filter the default gallery shortcode CSS styles.
	 *
	 * @since 2.5.0
	 *
	 * @param string $gallery_style Default CSS styles and opening HTML div container
	 *                              for the gallery shortcode output.
	 */
	$output = apply_filters( 'gallery_style', $gallery_style . $gallery_div );

	$i = 0;


	// Lightbox Gallery
	if ( $atts['type'] == 'lightbox' ) {
		$gallery_icon = mixt_element_get_icon('format-gallery');
		$image_count  = '<p class="count">' . count($attachments) . __(' pictures', 'mixt-elements' ) . '</p>';

		$output = '<div class="lightbox-trigger">' . wp_get_attachment_image(key($attachments), $atts['size']) . "<div class='inner'>{$gallery_icon}{$image_count}</div></div>" . $output;

		foreach ( $attachments as $id => $attachment ) {
			$itemclass = 'gallery-item';
			$image = wp_get_attachment_image_src($id, 'full')[0];
			$thumb = wp_get_attachment_image($id, 'mixt-small');
			$itemattr = "data-src='$image'";
			// Captions
			if ( $captiontag && trim($attachment->post_excerpt) ) {
				$itemattr .= ' data-sub-html="&lt;div&gt;' . wptexturize($attachment->post_excerpt) . '&lt;/div&gt;"';
			}
			// Output item
			$output .= "<$itemtag class='$itemclass' $itemattr>$thumb</$itemtag>";
		}

	// Standard & Slider Gallery
	} else {
		foreach ( $attachments as $id => $attachment ) {
			$attr = ( trim( $attachment->post_excerpt ) ) ? array( 'aria-describedby' => "$selector-$id" ) : '';
			if ( ! empty( $atts['link'] ) && 'file' === $atts['link'] ) {
				$image_output = wp_get_attachment_link( $id, $atts['size'], false, false, false, $attr );
			} elseif ( ! empty( $atts['link'] ) && 'none' === $atts['link'] ) {
				$image_output = wp_get_attachment_image( $id, $atts['size'], false, $attr );
			} else {
				$image_output = wp_get_attachment_link( $id, $atts['size'], true, false, false, $attr );
			}
			$image_meta  = wp_get_attachment_metadata( $id );

			$orientation = '';
			if ( isset( $image_meta['height'], $image_meta['width'] ) ) {
				$orientation = ( $image_meta['height'] > $image_meta['width'] ) ? 'portrait' : 'landscape';
			}
			$output .= "<{$itemtag} class='gallery-item'>";
			$output .= "
				<{$icontag} class='gallery-icon {$orientation}'>
					$image_output
				</{$icontag}>";
			if ( $captiontag && trim($attachment->post_excerpt) ) {
				$output .= "
					<{$captiontag} class='wp-caption-text gallery-caption' id='$selector-$id'>
					" . wptexturize($attachment->post_excerpt) . "
					</{$captiontag}>";
			}
			$output .= "</{$itemtag}>";
			if ( ! $html5 && $columns > 0 && ++$i % $columns == 0 ) {
				$output .= '<br style="clear: both" />';
			}
		}
	}

	$output .= "</$conttag>\n";

	return $output;
}


/**
 * Remove default WP gallery shortcode and register custom one, add gallery type setting
 */
function mixt_init_gallery() {
	add_action('print_media_templates', function() {
		?>

		<script type="text/html" id="tmpl-mixt-gallery-type">
			<label class="setting">
				<span><?php esc_html_e( 'Gallery Type', 'mixt-elements' ); ?></span>
				<select data-setting="type">
					<option value="standard"><?php esc_html_e( 'Standard', 'mixt-elements' ); ?></option>
					<option value="slider"><?php esc_html_e( 'Slider', 'mixt-elements' ); ?></option>
					<option value="lightbox"><?php esc_html_e( 'Lightbox', 'mixt-elements' ); ?></option>
				</select>
			</label>
		</script>

		<script>
			jQuery(document).ready( function() {
				_.extend(wp.media.gallery.defaults, {
					type: 'std'
				});

				wp.media.view.Settings.Gallery = wp.media.view.Settings.Gallery.extend({
					template: function(view){
						return wp.media.template('gallery-settings')(view)
						+ wp.media.template('mixt-gallery-type')(view);
					}
				});

			});
		</script>

		<?php
	});

	remove_shortcode('gallery');
	add_shortcode('gallery', 'mixt_gallery_shortcode');
}
add_action('init', 'mixt_init_gallery');
