<?php

// Grid Builder Custom Hover Content

/**
 * Add hover content shortcode to element list
 */
function mixt_gitem_hover($shortcodes) {
	$colors = mixt_element_assets('colors', 'basic');
	$anims  = array(
		'in' => mixt_element_assets('css-anims', 'trans-in'),
		'out' => mixt_element_assets('css-anims', 'trans-out')
	);
	$btn_colors = mixt_element_assets('colors', 'buttons');

	$shortcodes['mixt_gitem_hover'] = array(
		'name'        => esc_html__( 'Hover Content', 'mixt-elements' ),
		'description' => esc_html__( 'Custom Hover Content', 'mixt-elements' ),
		'base'        => 'mixt_gitem_hover',
		'category'    => 'MIXT',
		'post_type'   => Vc_Grid_Item_Editor::postType(),
		'params'      => array(
			array(
				'type'       => 'checkbox',
				'heading'    => esc_html__( 'Link Post', 'mixt-elements' ),
				'param_name' => 'link_post',
				'std'        => true,
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Hover Color', 'mixt-elements' ),
				'param_name' => 'hover_color',
				'value'      => array_flip($colors),
				'param_holder_class' => 'color-select basic-colors',
				'std'        => 'black',
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Hover Animation In', 'mixt-elements' ),
				'param_name' => 'hover_in',
				'value'      => array_flip($anims['in']),
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Hover Animation Out', 'mixt-elements' ),
				'param_name' => 'hover_out',
				'value'      => array_flip($anims['out']),
			),
			array(
				'type'       => 'checkbox',
				'heading'    => esc_html__( 'Items to Display', 'mixt-elements' ),
				'param_name' => 'items',
				'value'      => array(
					esc_html__( 'Title', 'mixt-elements' ) => 'title',
					esc_html__( 'Excerpt', 'mixt-elements' ) => 'excerpt',
					esc_html__( 'Full Image', 'mixt-elements' ) => 'image',
					esc_html__( 'Go to Post', 'mixt-elements' ) => 'post',
					esc_html__( 'Comment Count', 'mixt-elements' ) => 'comments',
				),
				'std'        => 'title',
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Item Style', 'mixt-elements' ),
				'param_name' => 'item_style',
				'value'      => array(
					esc_html__( 'Plain', 'mixt-elements' ) => 'plain',
					esc_html__( 'Button', 'mixt-elements' ) => 'btn',
					esc_html__( 'Round Button', 'mixt-elements' ) => 'btn btn-round',
				),
				'std'        => 'plain',
			),
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Button Color', 'mixt-elements' ),
				'param_name' => 'btn_color',
				'value'      => array_flip($btn_colors),
				'param_holder_class' => 'color-select button-colors',
				'dependency' => array(
					'element' => 'item_style',
					'value'   => array('btn', 'btn btn-round'),
				),
				'std'        => 'accent',
			),
		),
	);
	return $shortcodes;
}
add_filter('vc_grid_item_shortcodes', 'mixt_gitem_hover');


/**
 * Render the hover content shortcode
 */
function mixt_gitem_hover_shortcode($atts) {
	extract( shortcode_atts( array(
		'link_post'   => true,
		'hover_color' => 'black',
		'hover_in'    => 'fadeIn',
		'hover_out'   => 'fadeOut',
		'items'       => 'title',
		'item_style'  => 'plain',
		'btn_color'   => 'accent',
	), $atts ) );

	$items = explode(',', $items);
	$item_classes = 'gitem-icon rollover-item ' . $item_style;
	if ( $item_style != 'plain' ) { $item_classes .= " btn-$btn_color no-border"; }
	$item_classes = mixt_element_sanitize_html_classes($item_classes);

	if ( function_exists('mixt_get_icon') ) {
		$post_icon = mixt_get_icon('view-post', false);
		$image_icon = mixt_get_icon('view-image', false);
		$comm_icon = mixt_get_icon('comments', false);
	} else {
		$post_icon = 'fa fa-share';
		$image_icon = 'fa fa-search';
		$comm_icon = 'fa fa-comment';
	}

	ob_start();
	?>
		<div class="mixt-gitem-hover post-rollover hover-content anim-on-hover anim-content">
			<div class="on-hover <?php echo sanitize_html_class($hover_color); ?>" data-anim-in="<?php echo esc_attr($hover_in); ?>" data-anim-out="<?php echo esc_attr($hover_out); ?>">
				<div class="inner">
					<?php if ( in_array('title', $items) ) { ?>
						<a href="{{ post_link_url }}" class="post-title no-color">{{ post_title }}</a>
					<?php } if ( in_array('excerpt', $items) ) { ?>
						<a href="{{ post_link_url }}" class="post-excerpt no-color">{{ post_excerpt }}</a>
					<?php } if ( in_array('post', $items) ) { ?>
						<a href="{{ post_link_url }}" class="<?php echo $item_classes; ?>" title="<?php esc_attr_e( 'View Post', 'mixt-elements' ); ?>" data-toggle="tooltip"><i class="<?php echo $post_icon; ?>"></i></a>
					<?php } if ( in_array('image', $items) ) { ?>
						<a href="{{ post_image_url }}" class="<?php echo $item_classes; ?>" title="<?php esc_attr_e( 'Full Image', 'mixt-elements' ); ?>" data-toggle="tooltip"><i class="<?php echo $image_icon; ?>"></i></a>
					<?php } if ( in_array('comments', $items) ) { ?>
						<a href="{{ post_link_url }}#comments" class="<?php echo $item_classes; ?> comments"><i class="<?php echo $comm_icon; ?>"></i>&nbsp;<small>{{ post_data:comment_count }}</small></a>
					<?php } ?>
				</div>
				<?php if ( $link_post ) { ?>
					<a href="{{ post_link_url }}" class="main-link"></a>
				<?php } ?>
			</div>
		</div>
	<?php
	return ob_get_clean();
}
add_shortcode('mixt_gitem_hover', 'mixt_gitem_hover_shortcode');