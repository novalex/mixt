<?php

/**
 * Plugin Name: MIXT Elements
 * Description: Highly versatile and customizable element shortcodes
 * Version:     1.0
 * Author:      novalex
 * Author URI:  http://novalx.com
 * Text Domain: mixt-elements
 * Domain Path: /lang/
 */

defined('ABSPATH') or die('You are not supposed to do that.'); // No Direct Access

// Set Constants

define( 'MIXTEL_VERSION', '1.0' );
define( 'MIXTEL_PLUGIN', __FILE__ );
define( 'MIXTEL_DIR', untrailingslashit( dirname(MIXTEL_PLUGIN) ) );
define( 'MIXTEL_INC_DIR', MIXTEL_DIR . '/inc' );
define( 'MIXTEL_ELEM_DIR', MIXTEL_DIR . '/elements' );
// Message to display for elements that require the MIXT theme
define( 'MIXTEL_DISABLED', '<p>'.__( 'This element requires the MIXT theme to be active!', 'mixt-elements' ).'</p>' );

if ( defined('MIXT_IMG_PLACEHOLDER') ) {
	define( 'MIXTEL_IMG_PLACEHOLDER', MIXT_IMG_PLACEHOLDER );
} else {
	define( 'MIXTEL_IMG_PLACEHOLDER', 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=' );
}

if ( ! class_exists('Mixt_Elements') ) {

	class Mixt_Elements {

		public function __construct() {
			$this->setup();

			add_action('init', array($this, 'register_elements'), 5);
			add_action('plugins_loaded', array($this, 'load_textdomain'));
		}

		/**
		 * Load includes
		 */
		public function setup() {
			require_once(MIXTEL_INC_DIR . '/common.php');
			require_once(MIXTEL_INC_DIR . '/class-element.php');

			include_once(MIXTEL_INC_DIR . '/gallery.php');
			include_once(MIXTEL_INC_DIR . '/widget-shortcode.php');

			if ( defined('WPB_VC_VERSION') ) {
				include_once(MIXTEL_INC_DIR . '/vc-grid-items.php');
			}
		}

		/**
		 * Load plugin textdomain
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'mixt-elements', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' ); 
		}

		/**
		 * Scan the elements directory and register them
		 */
		public function register_elements() {
			foreach ( glob( MIXTEL_ELEM_DIR . '/*.php' ) as $element ) {
				include $element;
			}
		}
	}
}
new Mixt_Elements;
