<?php

/**
 * Plugin Name: MIXT Portfolio
 * Description: Portfolio post types and taxonomy items
 * Version:     1.0
 * Author:      novalex
 * Author URI:  http://novalx.com
 * Text Domain: mixt-portfolio
 * Domain Path: /lang/
 */

defined('ABSPATH') or die('You are not supposed to do that.'); // No Direct Access

if ( ! class_exists('Mixt_Portfolio') ) {

	class Mixt_Portfolio {

		public function __construct() {
			add_action('init', array($this, 'register_post_types'), 5);
			add_action('init', array($this, 'register_taxonomies'), 5);

			add_filter('rewrite_rules_array', array($this, 'rewrite_rules'));

			add_filter('getarchives_where', array($this, 'getarchives_where_filter'), 10, 2);

			add_action('plugins_loaded', array($this, 'load_textdomain'));
		}

		/**
		 * Perform plugin install actions upon activation
		 */
		public static function install() {
			add_action('wp_loaded', 'flush_rewrite_rules');
		}

		/**
		 * Load plugin textdomain
		 */
		public function load_textdomain() {
			load_plugin_textdomain( 'mixt-portfolio', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' ); 
		}

		/**
		 * Register custom post types
		 */
		public function register_post_types() {
			$portfolio_args = array(
				'labels'         => array(
					'name'          => __( 'Portfolio', 'mixt-portfolio'),
					'singular_name' => __( 'Project', 'mixt-portfolio'),
					'search_items'  => __( 'Search Projects', 'mixt-portfolio'),
					'all_items'     => __( 'Portfolio', 'mixt-portfolio'),
					'parent_item'   => __( 'Parent Project', 'mixt-portfolio'),
					'edit_item'     => __( 'Edit Project', 'mixt-portfolio'),
					'update_item'   => __( 'Update Project', 'mixt-portfolio'),
					'add_new_item'  => __( 'Add New Project', 'mixt-portfolio'),
				),
				'public'         => true,
				'show_ui'        => true,
				'menu_position'  => '9.6498',
				'hierarchical'   => false,
				'query_var'      => true,
				'rewrite'        => true,
				'has_archive'    => true,
				'menu_icon'      => 'dashicons-portfolio',
				'supports'       => array( 'author', 'title', 'editor', 'excerpt', 'thumbnail', 'comments', 'revisions', 'custom-fields', 'post-formats' ),
				'show_in_menu'   => true,
				'show_in_nav_menus' => true,
			);
			register_post_type('portfolio' , $portfolio_args);
		}

		/**
		 * Register custom taxonomies
		 */
		public function register_taxonomies() {
			// Project Types
			register_taxonomy(
				'project-type',
				'portfolio',
				array(
					'labels'       => array(
						'name'          => __( 'Project Types', 'mixt-portfolio'),
						'singular_name' => __( 'Project Type', 'mixt-portfolio'),
						'search_items'  => __( 'Search Project Types', 'mixt-portfolio'),
						'all_items'     => __( 'All Project Types', 'mixt-portfolio'),
						'parent_item'   => __( 'Parent Project Type', 'mixt-portfolio'),
						'edit_item'     => __( 'Edit Project Type', 'mixt-portfolio'),
						'update_item'   => __( 'Update Project Type', 'mixt-portfolio'),
						'add_new_item'  => __( 'Add New Project Type', 'mixt-portfolio'),
						'new_item_name' => __( 'New Project Type', 'mixt-portfolio'),
						'menu_name'     => __( 'Project Types', 'mixt-portfolio'),
					),
					'show_ui'      => true,
					'hierarchical' => true,
					'query_var'    => true,
					'rewrite'      => true,
				)
			);

			// Project Attributes
			register_taxonomy(
				'project-attributes',
				'portfolio',
				array(
					'labels'       => array(
						'name'          => __( 'Project Attributes', 'mixt-portfolio'),
						'singular_name' => __( 'Project Attribute', 'mixt-portfolio'),
						'search_items'  => __( 'Search Project Attributes', 'mixt-portfolio'),
						'all_items'     => __( 'All Project Attributes', 'mixt-portfolio'),
						'parent_item'   => __( 'Parent Project Attribute', 'mixt-portfolio'),
						'edit_item'     => __( 'Edit Project Attribute', 'mixt-portfolio'),
						'update_item'   => __( 'Update Project Attribute', 'mixt-portfolio'),
						'add_new_item'  => __( 'Add New Project Attribute', 'mixt-portfolio'),
						'new_item_name' => __( 'New Project Attribute', 'mixt-portfolio'),
						'menu_name'     => __( 'Project Attributes', 'mixt-portfolio'),
					),
					'show_ui'      => true,
					'hierarchical' => true,
					'query_var'    => true,
					'rewrite'      => true,
				)
			);

			// Project Formats
			register_taxonomy_for_object_type('post_format', 'portfolio');
		}

		/**
		 * Generate portfolio post type rewrite rules for date archives
		 * 
		 * @param  string $cpt  The custom post type for which to generate rules
		 */
		public function rewrite_rules($rewrite_rules) {
			global $wp_rewrite;

			$rules = array();

			$dates = array(
				array(
					'rule' => "([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})",
					'vars' => array('year', 'monthnum', 'day'),
				),
				array(
					'rule' => "([0-9]{4})/([0-9]{1,2})",
					'vars' => array('year', 'monthnum'),
				),
				array(
					'rule' => "([0-9]{4})",
					'vars' => array('year'),
				),
			);

			foreach ( $dates as $data ) {
				$query = 'index.php?post_type=portfolio';
				$rule = 'portfolio/'.$data['rule'];

				$i = 1;
				foreach ( $data['vars'] as $var ) {
					$query .= '&amp;'.$var.'='.$wp_rewrite->preg_index($i);
					$i++;
				}

				$rules[$rule."/?$"] = $query;
				$rules[$rule."/feed/(feed|rdf|rss|rss2|atom)/?$"] = $query."&amp;feed=".$wp_rewrite->preg_index($i);
				$rules[$rule."/(feed|rdf|rss|rss2|atom)/?$"] = $query."&amp;feed=".$wp_rewrite->preg_index($i);
				$rules[$rule."/page/([0-9]{1,})/?$"] = $query."&amp;paged=".$wp_rewrite->preg_index($i);
			}

			return array_merge($rules, $rewrite_rules);
		}

		/**
		 * Modify the query to show only portfolio type posts
		 */
		function getarchives_where_filter($where, $args) {
			if ( isset($args['post_type']) && $args['post_type'] == 'portfolio' ) {      
				$where = "WHERE post_type = 'portfolio' AND post_status = 'publish'";
			}
			return $where;
		}
	}
}
new Mixt_Portfolio();

register_activation_hook(__FILE__, array('Mixt_Portfolio', 'install'));

register_deactivation_hook(__FILE__, 'flush_rewrite_rules');


if ( ! function_exists('mixt_portfolio_filters') ) {
	/**
	 * Output portfolio filtering links
	 */
	function mixt_portfolio_filters() {
		$terms = get_terms('project-type');

		if ( empty($terms) ) { return; }

		$output = '<ul class="portfolio-sorter link-list">';
			$output .= '<li class="active"><a href="#" data-sort="all">' . _x( 'All', 'portfolio filter', 'mixt-portfolio' ) . '</a></li>';
			foreach ( $terms as $term ) {
				$name = $term->name;
				$sort = $term->taxonomy . '-' . $term->slug;

				$output .= '<li><a href="#" data-sort="' . $sort . '">' . $name . '</a></li>';
			}
		$output .= '</ul>';

		echo $output;
	}
}